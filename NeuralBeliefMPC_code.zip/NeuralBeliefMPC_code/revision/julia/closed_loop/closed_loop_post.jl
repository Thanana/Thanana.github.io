# Closed-loop deployment of the mean-only correction postprocessors of Sec. III-E.
# Usage: julia --project=PLANT closed_loop_post.jl PLANT_COPY PROFILE SEED POLICY UC
#   POLICY in scalar | dir1 | dirN ;  UC = correction-input tolerance [N] (update tolerance 0.1 UC).
# The MM--CF binding observer, its adaptation, score and coupling gate are unchanged. At each
# fully observed tick with a positive radius and an in-cell reference, the deployed physical mean
# offset is replaced by its projection onto S_B (scalar) or D_B (H=1 or H=N) at the reference
# covariance (Theorem 3 setting). Other ticks keep the original map. No hyperparameter is selected.
using Serialization,LinearAlgebra,DelimitedFiles,OSQP,SparseArrays,Printf
folder=abspath(ARGS[1]);profile=Symbol(ARGS[2]);seed=parse(Int,ARGS[3]);policy=Symbol(ARGS[4]);uc=parse(Float64,ARGS[5])
include(joinpath(folder,"run_standard_benchmark.jl"))
const PLANT=NP==1 ? "single" : "double"
const GU=Matrix{Float64}(readdlm(joinpath(@__DIR__,"G_U_$(PLANT).csv"),','))
const CM=Matrix{Float64}(readdlm(joinpath(folder,"audit/cell_M.csv"),','));const CB=vec(readdlm(joinpath(folder,"audit/cell_b.csv"),','))
const SX=ZS[1:NX];const AC=CM.*reshape(SX,1,:);const DEN=vec(sqrt.(sum(AC.^2;dims=2)));const NZR=DEN.>0
const GAIN=NP==1 ? 21.100612 : 79.946563
const HOR=policy==:dirN ? size(GU,1) : 1
const LOG=Any[]
# Exact projection onto a polyhedron by least-distance programming (Lawson--Hanson NNLS);
# the Euclidean ball is handled by bisection on its multiplier. No iterative tolerance is involved.
function nnls_lh(E,f)
    n,m=size(E);x=zeros(m);P=falses(m);w=E'*(f-E*x)
    tol=10*eps()*opnorm(E,1)*max(n,m);it=0;maxit=3m
    while any(.!P) && maximum(ifelse.(.!P,w,-Inf))>tol && it<maxit
        j=argmax(ifelse.(.!P,w,-Inf));P[j]=true;z=zeros(m)
        while true
            it+=1;z=zeros(m);z[P]=E[:,P]\f
            (all(z[P].>tol)||it>maxit)&&break
            Q=P.&(z.<=tol);alpha=minimum(x[Q]./(x[Q].-z[Q]));x=x.+alpha.*(z.-x);P=P.&(x.>tol)
        end
        x=z;w=E'*(f-E*x)
    end
    x
end
function project_poly(c,A,lo,hi)
    fin=isfinite.(lo)
    G=vcat(-A,A[fin,:]);h=vcat(A*c-hi,lo[fin]-A[fin,:]*c)
    nr=vec(sqrt.(sum(G.^2;dims=2)));G=G./nr;h=h./nr
    n=size(G,2);E=vcat(Matrix(G'),reshape(h,1,:));f=zeros(n+1);f[end]=1.
    u=nnls_lh(E,f);r=E*u-f
    abs(r[end])<1e-14&&error("LDP: infeasible polyhedron")
    c-r[1:n]/r[end]
end
function project_dir(q,R,s)
    G=GU[1:HOR,:];A=vcat(AC[NZR,:]./DEN[NZR],G);hi=vcat(.99 .*s[NZR]./DEN[NZR],fill(uc,HOR));lo=vcat(fill(-Inf,sum(NZR)),fill(-uc,HOR))
    d=project_poly(q,A,lo,hi)
    norm(d)<=R&&return d
    a,b=0.,norm(q)/R-1   # ||Pi_P(q/(1+mu))|| <= ||q||/(1+mu) because 0 is in P
    for _ in 1:60
        mu=(a+b)/2;x=project_poly(q/(1+mu),A,lo,hi);nx_=norm(x)
        abs(nx_-R)<=1e-12*R&&return x*min(1.,R/nx_)
        nx_>R ? (a=mu) : (b=mu)
    end
    x=project_poly(q/(1+b),A,lo,hi);x*min(1.,R/norm(x))
end
function postprocess(nn,ctx,m,P,newm,newP)
    R=ctx.trust_radius
    (R<=0||!all(ctx.mask))&&return newm,newP
    raw,_=neural_encoder(nn.re_phi(nn.phi),reshape(ctx.features,:,1),reshape(ctx.mean,:,1),nn.emean,nn.escale)
    q=vec(raw)[1:NX]-m[1:NX];s=CB-CM*(SX.*m[1:NX])
    if minimum(s)<0
        push!(LOG,(fallback=1,dnorm=NaN,plan=NaN,viol=NaN));return newm,newP
    end
    rs=min(R,.99minimum(s[NZR]./DEN[NZR]),uc/GAIN)
    d=policy==:scalar ? q*min(1.,rs/max(norm(q),1e-300)) : project_dir(q,R,s)
    viol=max(norm(d)-(policy==:scalar ? rs : R),maximum(AC[NZR,:]*d .- .99 .*s[NZR]),maximum(abs.(GU[1:HOR,:]*d))-uc)
    push!(LOG,(fallback=0,dnorm=norm(d),plan=maximum(abs.(GU*d))/uc,viol=viol))
    out=copy(newm);out[1:NX]=m[1:NX]+d
    out,copy(P)
end
src=read(joinpath(folder,"imm_anchor.jl"),String)
k=findfirst("function correct_neural!(obs::IMMAnchorObserver",src);fn=src[first(k):end]
anchor="d=adapt_neural!(base,ctx);newm,newP=encoded_belief(nn,ctx)"
occursin(anchor,fn)||error("anchor not found in imm_anchor.jl")
fn=replace(fn,anchor=>anchor*";newm,newP=postprocess(nn,ctx,m,P,newm,newP)")
Base.include_string(Main,fn,"correct_neural_post.jl")
BLAS.set_num_threads(1);config=deserialize(joinpath(folder,"selected_config.jls"))
out=joinpath(folder,"closed_loop_$(policy)_uc$(uc)");mkpath(out)
t0=time();result=episode(profile,:mm_binding,seed,design_load(),read_bundle(),out;radius=config.radius,budget=config.budget)
L=filter(x->x.fallback==0,LOG)
row=(plant=PLANT,profile=profile,seed=seed,policy=policy,uc=uc,complete=result.complete,zero_violation=result.zero_violation,
  violating_intervals=result.violating_intervals,lqr_recovery=result.lqr_recovery,angle_tracking_rmse_deg=result.angle_tracking_rmse_deg,
  angle_estimation_rmse_deg=result.angle_estimation_rmse_deg,post_ticks=length(L),fallback_ticks=length(LOG)-length(L),
  max_plan_over_uc=isempty(L) ? NaN : maximum(x.plan for x in L),median_plan_over_uc=isempty(L) ? NaN : sort([x.plan for x in L])[cld(length(L),2)],
  max_constraint_violation=isempty(L) ? NaN : maximum(x.viol for x in L),seconds=time()-t0)
open(joinpath(out,"summary_$(profile)_seed$(seed).csv"),"w") do io
 println(io,join(string.(keys(row)),','));println(io,join(string.(values(row)),','))
end
println(row)
