#!/bin/bash
# Closed-loop test of the remapped corrections (scalar budget / N_h=1 / N_h=N). Run on the Mac:
#   cd revision/julia/closed_loop
#   PLANTS=double SEEDS=96301 PROFILES=nominal UCS=0.01 bash run_closed_loop.sh   # quick check (~3 min)
#   bash run_closed_loop.sh                                                       # full run
# Reuses the plant copies made by ../run_all.sh. Re-running skips finished cases.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="${OUT:-$HERE/../../output}"; OUT="$(cd "$OUT" && pwd)"
JULIA="${JULIA:-julia}"
PLANTS="${PLANTS:-double}"
PROFILES="${PROFILES:-nominal mass bias dropout combined}"
SEEDS="${SEEDS:-96301 96302 96303 96304 96305}"
UCS="${UCS:-0.001 0.01}"
POLICIES="${POLICIES:-scalar dir1 dirN}"
for plant in $PLANTS; do
  P="$OUT/bench/standard_benchmark/$plant"
  for seed in $SEEDS; do for profile in $PROFILES; do
    V="$OUT/$plant/${profile}_seed${seed}"
    [ -d "$V" ] || { echo "missing $V (run ../run_all.sh first)"; exit 1; }
    for uc in $UCS; do for pol in $POLICIES; do
      S="$V/closed_loop_${pol}_uc${uc}/summary_${profile}_seed${seed}.csv"
      [ -f "$S" ] && { echo "skip $plant $profile $seed $pol $uc"; continue; }
      echo "=== $plant $profile $seed $pol uc=$uc : $(date)"
      "$JULIA" --startup-file=no --project="$P" "$HERE/closed_loop_post.jl" "$V" "$profile" "$seed" "$pol" "$uc" 2>&1 | tail -25
    done; done
  done; done
done
echo "Finished: $(date). Summarize with ../../analysis/closed_loop_summary.py."
