#!/bin/bash
# Regenerate Fig. 3 (PAM, single column) in Julia from the archived PAM traces.
# Needs Julia with CairoMakie; uses the Times New Roman system font path of macOS (edit plot_pam_column.jl elsewhere).
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
TRACES="${TRACES:-$HERE/../../../pam_surrogate/results_pam_v4}"
julia "$HERE/plot_pam_column.jl" "$TRACES" "$HERE/pam_validation_column"
