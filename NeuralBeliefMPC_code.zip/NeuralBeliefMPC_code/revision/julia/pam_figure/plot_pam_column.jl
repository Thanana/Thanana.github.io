# Single-column PAM figure (Fig. 3 of the TAC TN), same data and encodings as plot_pam_inset.jl.
# Usage: julia plot_pam_column.jl <dir with trace_*.csv> <output prefix>
using CairoMakie, DelimitedFiles
CairoMakie.activate!()
D = abspath(ARGS[1]); out = ARGS[2]
TNR = "/System/Library/Fonts/Supplemental/Times New Roman.ttf"
TNRB = "/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf"
set_theme!(Theme(font=TNR, fonts=(regular=TNR, bold=TNRB), fontsize=8,
    Axis=(xgridcolor=(:gray, .25), ygridcolor=(:gray, .25), xgridwidth=.4, ygridwidth=.4,
          topspinevisible=false, rightspinevisible=false, spinewidth=.6,
          titlefont=:regular, titlesize=8, xlabelsize=8, ylabelsize=8,
          xticklabelsize=7, yticklabelsize=7, xtickwidth=.6, ytickwidth=.6,
          xticksize=3, yticksize=3, titlegap=3)))
function trace(m)
    a, h = readdlm(joinpath(D, "trace_$m.csv"), ',', Any, '\n'; header=true)
    Dict(string(n) => Float64.(a[:, j]) for (j, n) in enumerate(vec(h)))
end
sy(x) = sign(x) * log10(1 + abs(x))
ticks = [-100., -6, 0, 6, 100]
methods = ["bias_ekf", "frozen", "cf", "unprojected"]
cols = ["#777777", "#8a5acb", "#2778c4", "#ed729f"]
labels = ["Bias EKF", "Projected frozen", "CF encoder", "No projection"]
T = Dict(m => trace(m) for m in methods)
ls(j) = methods[j] == "frozen" ? :dash : :solid
lw(j) = j == 4 ? .8 : 1.0

f = Figure(size=(248, 227), figure_padding=(2, 4, 2, 2))   # 3.45 x 3.15 in at pt_per_unit = 1
yt = (sy.(ticks), [string(round(Int, v)) for v in ticks])
a1 = Axis(f[1, 1], title="(a) PAM tracking, seed 94026", ylabel="position [cm]", yticks=yt)
a2 = Axis(f[2, 1], title="(b) Estimation error", ylabel="estimate − truth [cm]", xlabel="time [s]", yticks=yt)
linkxaxes!(a1, a2); hidexdecorations!(a1; grid=false, ticks=false, minorticks=false)
for j in [1, 4, 3, 2]
    d = T[methods[j]]
    lines!(a1, d["time"], sy.(100 .* d["q"]), color=cols[j], linestyle=ls(j), linewidth=lw(j))
    lines!(a2, d["time"], sy.(100 .* (d["q_hat"] .- d["q"])), color=cols[j], linestyle=ls(j), linewidth=lw(j))
end
dref = T["cf"]; lines!(a1, dref["time"], sy.(100 .* dref["reference"]), color=:black, linestyle=:dash, linewidth=.9)
for ax in (a1, a2)
    vspan!(ax, 48, 49, color=(:gray, .15)); vlines!(ax, [26., 60.], color=:gray, linestyle=:dash, linewidth=.7)
    xlims!(ax, 0, 80); ylims!(ax, -2.15, 2.15)   # full signed-log range, ticks -100 ... 100 always visible
    ax.xticks = 0:10:80
end
hlines!(a1, sy.([-6., 6.]), color=:gray, linestyle=:dot, linewidth=.8)
# Linear inset keeps the archived error values without signed-log compression; frozen drawn last (dashed).
ins = Axis(f[2, 1], width=Relative(.64), height=Relative(.30), halign=.92, valign=.17,
    tellwidth=false, tellheight=false, backgroundcolor=:white,
    topspinevisible=true, rightspinevisible=true, spinewidth=.5,
    xticks=[0, 40, 80], yticks=[0, .5, 1], xticklabelsize=6, yticklabelsize=6,
    xticksize=2, yticksize=2, xticklabelpad=1, yticklabelpad=1)
translate!(ins.blockscene, 0, 0, 100)
for j in [1, 3, 2]
    d = T[methods[j]]
    lines!(ins, d["time"], 100 .* (d["q_hat"] .- d["q"]), color=cols[j], linestyle=ls(j), linewidth=.8)
end
vspan!(ins, 48, 49, color=(:gray, .12)); vlines!(ins, [26., 60.], color=:gray, linestyle=:dash, linewidth=.5)
xlims!(ins, 0, 80); ylims!(ins, -.35, 1.25)
text!(ins, .02, .93, text="linear zoom [cm]", space=:relative, fontsize=6, align=(:left, :top))
el = [LineElement(color=cols[j], linestyle=ls(j), linewidth=1.2) for j in 1:4]
push!(el, LineElement(color=:black, linestyle=:dash, linewidth=.9))
Legend(f[3, 1], el, vcat(labels, ["Desired position"]), orientation=:horizontal, nbanks=2,
    framevisible=false, labelsize=7, patchsize=(16, 6), colgap=6, rowgap=0, padding=(0, 0, 0, 0))
rowgap!(f.layout, 1, 6); rowgap!(f.layout, 2, 4)
save(out * ".pdf", f; pt_per_unit=1)
save(out * ".png", f; px_per_unit=3)
println("saved ", out, ".pdf/.png")
