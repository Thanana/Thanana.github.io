# Coded by Thanana of the Control Lab.

using LinearAlgebra,DelimitedFiles,SHA
base=abspath(ARGS[1]);study=abspath(ARGS[2]);out=abspath(ARGS[3]);mkpath(out)
include(joinpath(base,"mpc_core.jl"));include(joinpath(base,"neural_adaptation.jl"))
BLAS.set_num_threads(1)
nn=read_bundle();nphi=length(nn.phi);anchor=vcat(nn.anchor_phi,nn.anchor_theta)
trials,header=readdlm(joinpath(study,"trials.csv"),',',Any,'\n';header=true)
cols=Dict(string(v)=>j for (j,v) in enumerate(vec(header)))
for folder in sort(filter(p->isdir(p)&&startswith(basename(p),"record_"),readdir(joinpath(base,"guard_replay");join=true)))
 rec=basename(folder);old=vec(readdlm(joinpath(folder,"old.csv"),','));delta=vec(readdlm(joinpath(study,rec,"proposal.csv"),','))
 ids=findall((string.(trials[:,cols["record"]]).==rec).&(Int.(trials[:,cols["score_pass"]]).==1))
 j=isempty(ids) ? 0 : Int(trials[first(ids),cols["trial"]])
 v=j==0 ? old : project_candidate(old+2.0^(-(j-1))*delta,anchor)
 F=Matrix{Float64}(readdlm(joinpath(folder,"features.csv"),','));M=Matrix{Float64}(readdlm(joinpath(folder,"mean.csv"),','))
 ro,_=neural_encoder(nn.re_phi(old[1:nphi]),F,M,nn.emean,nn.escale)
 rn,_=neural_encoder(nn.re_phi(v[1:nphi]),F,M,nn.emean,nn.escale)
 dest=joinpath(out,rec);mkpath(dest)
 writedlm(joinpath(dest,"raw.csv"),hcat(vec(ro-M)[1:NX],vec(rn-M)[1:NX]),',')
 write(joinpath(dest,"selected_trial.txt"),string(j))
end
println("Extracted raw mean-only proposals for ",basename(base)," (98 contexts).")
