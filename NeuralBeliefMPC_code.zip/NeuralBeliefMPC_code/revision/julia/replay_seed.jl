# Frozen-context replay for one (profile, seed) of the MM--CF binding observer.
# Generalizes standard_benchmark/run_guard_replay.jl (which is fixed to combined/96301).
# Usage: julia --project=PLANT replay_seed.jl PLANT_COPY PROFILE SEED
# Writes PLANT_COPY/guard_replay/record_###/*.csv and the episode log. No hyperparameter is selected.
# Coded by Thanana of the Control Lab.

using Serialization,LinearAlgebra,DelimitedFiles
folder=abspath(ARGS[1]);profile=Symbol(ARGS[2]);seed=parse(Int,ARGS[3])
include(joinpath(folder,"run_standard_benchmark.jl"))
const AUDIT_RECORDS=Any[]
source=read(joinpath(folder,"neural_adaptation.jl"),String)
source=replace(source,"include(\"neural_core.jl\")"=>"")
source=replace(source,"const GATE_BUDGET=Ref(.002)"=>"")
hook="""
    push!(AUDIT_RECORDS,(old=copy(old),candidate=copy(candidate),ctx=deepcopy(ctx),batch=deepcopy(batch),
       accepted=accepted,step=js,coupling=coupling,loss_before=before,loss_after=after,
       budget=GATE_BUDGET[],rejections=blocks))
"""
occursin("    (attempted=true,accepted=accepted,trials=trials",source)||error("hook anchor not found in neural_adaptation.jl")
source=replace(source,"    (attempted=true,accepted=accepted,trials=trials"=>hook*"    (attempted=true,accepted=accepted,trials=trials")
Base.include_string(Main,source,joinpath(folder,"neural_adaptation.jl"))
BLAS.set_num_threads(1);config=deserialize(joinpath(folder,"selected_config.jls"));out=joinpath(folder,"guard_replay");mkpath(out)
result=episode(profile,:mm_binding,seed,design_load(),read_bundle(),out;radius=config.radius,budget=config.budget)
open(joinpath(out,"summary.txt"),"w") do io;println(io,result);end
fields=("old","candidate","features","mean","cov","F","M","U","Y","W","Cdiag","radii")
for (i,record) in enumerate(AUDIT_RECORDS)
 dir=joinpath(out,"record_"*lpad(i,3,'0'));mkpath(dir)
 values=(record.old,record.candidate,record.ctx.features,record.ctx.mean,record.ctx.cov,
     record.batch.F,record.batch.M,record.batch.U,record.batch.Y,reshape(record.batch.W,NY*NY,:),record.batch.Cdiag,record.batch.radii)
 for (name,value) in zip(fields,values);writedlm(joinpath(dir,name*".csv"),value,',');end
 writedlm(joinpath(dir,"diagnostics.csv"),reshape([Int(record.accepted),record.step,record.coupling,record.loss_before,record.loss_after,record.budget,record.rejections,record.ctx.trust_radius],1,:),',')
end
println(result);println("Frozen-context records: ",length(AUDIT_RECORDS)," (",profile,", seed ",seed,")")
