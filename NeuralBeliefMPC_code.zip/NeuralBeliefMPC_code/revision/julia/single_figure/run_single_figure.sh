#!/bin/bash
# Regenerate Fig. 2 (Single IP observer budgets, single column) in Julia from the archived test records.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
julia "$HERE/plot_single_column.jl" "$HERE/data" "$HERE/standard_single_budgets_column"
