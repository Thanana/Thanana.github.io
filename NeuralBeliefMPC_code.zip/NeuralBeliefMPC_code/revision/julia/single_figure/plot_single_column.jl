# Single-column Fig. 2 (Single IP, combined profile, seed 96301): observer budget ratios.
# Same data and encodings as panel (b) of plot_ip_readable.jl (Supplement Fig. S1).
# Usage: julia plot_single_column.jl <folder containing single/test/*.csv> <output prefix>
# Coded by Thanana of the Control Lab.

using CairoMakie, DelimitedFiles
CairoMakie.activate!()
ROOT = abspath(ARGS[1]); out = ARGS[2]
TNR = "/System/Library/Fonts/Supplemental/Times New Roman.ttf"
TNRB = "/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf"
set_theme!(Theme(font=TNR, fonts=(regular=TNR, bold=TNRB), fontsize=7,
    Axis=(xgridcolor=(:gray, .2), ygridcolor=(:gray, .2), xgridwidth=.4, ygridwidth=.4,
          spinewidth=.6, titlefont=:regular, titlesize=7, xlabelsize=7, ylabelsize=7,
          xticklabelsize=6, yticklabelsize=6, xtickwidth=.6, ytickwidth=.6,
          xticksize=2.5, yticksize=2.5, titlegap=2, xlabelpadding=1, ylabelpadding=2)))
function raw(method; profile="combined", seed=96301)
    p = joinpath(ROOT, "single", "test", "$(profile)_$(method)_seed$(seed).csv")
    names = split(readline(p), ','); a = readdlm(p, ','; skipstart=1)
    Dict(n => Float64.(a[:, j]) for (j, n) in enumerate(names))
end
cols = Dict(:neural_encoder => "#CC3978", :mm_adapt => "#2672C9", :mm_binding => "#008C7C")
labels = Dict(:neural_encoder => "Neural CF encoder", :mm_adapt => "MM–CF", :mm_binding => "MM–CF binding")
function events!(ax)
    vspan!(ax, 12, 12.4; color=(:gray, .13)); vlines!(ax, [8.]; color=(:gray, .8), linestyle=:dash, linewidth=.6)
    hlines!(ax, [1.]; color=:black, linestyle=:dash, linewidth=.6)
    xlims!(ax, 0, 20); ylims!(ax, 0, 1.12); ax.xticks = 0:5:20; ax.yticks = [0, .5, 1]
    ax.ytickformat = v -> [isinteger(x) ? string(round(Int, x)) : string(x) for x in v]
end
f = Figure(size=(248, 200), figure_padding=(1, 4, 1, 1))   # 3.45 in wide at pt_per_unit = 1
a1 = Axis(f[1, 1], ylabel="correction /\nradius")
a2 = Axis(f[2, 1], ylabel="step /\nbudget")
a3 = Axis(f[3, 1], ylabel="coupling /\ngate budget", xlabel="time [s]")
for m in [:neural_encoder, :mm_binding]                     # every tick: deployed correction / radius
    d = raw(m); k = findall(d["radius"] .> 0)
    lines!(a1, d["time"][k], d["reference_coupling"][k] ./ d["radius"][k]; color=cols[m], linewidth=.8)
end
for m in [:mm_adapt, :mm_binding]                            # accepted updates only
    d = raw(m); k = findall(d["accepted"] .> 0)
    scatterlines!(a2, d["time"][k], d["step"][k] ./ .002; color=cols[m], markersize=2.5, linewidth=.5)
    if m == :mm_binding
        scatter!(a3, d["time"][k], d["coupling"][k] ./ d["gate_budget"][k]; color=cols[m], markersize=2.5)
    end
end
for ax in (a1, a2, a3); events!(ax); end
hidexdecorations!(a1; grid=false, ticks=false); hidexdecorations!(a2; grid=false, ticks=false)
elems = [LineElement(color=cols[m], linewidth=1.2) for m in [:neural_encoder, :mm_adapt, :mm_binding]]
Legend(f[4, 1], elems, [labels[m] for m in [:neural_encoder, :mm_adapt, :mm_binding]];
       orientation=:horizontal, framevisible=false, labelsize=6.5, patchsize=(12, 5), colgap=6, padding=(0, 0, 0, 0))
rowgap!(f.layout, 3); rowgap!(f.layout, 3, 2)
save(out * ".pdf", f; pt_per_unit=1); save(out * ".png", f; px_per_unit=4)
println("saved ", out, ".pdf/.png")
