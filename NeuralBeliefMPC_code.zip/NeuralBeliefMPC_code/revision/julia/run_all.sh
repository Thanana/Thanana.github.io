#!/bin/bash
# Multi-seed replay and frozen-context extraction (Sec. IV-D of the paper). Run from this folder:
#   cd revision/julia
#   bash run_all.sh                       # full: 2 plants x 5 profiles x 5 seeds
#   SEEDS=96301 PROFILES=combined bash run_all.sh   # quick check (reproduces the archived study)
# Needs Julia 1.12.x on PATH (or set JULIA=/path/to/julia). Works on a COPY of ../../standard_benchmark;
# archived records are never modified. Re-running skips finished cases (DONE marker).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="${SRC:-$HERE/../../standard_benchmark}"            # archived pinned plant folders
OUT="${OUT:-$HERE/../output}"
JULIA="${JULIA:-julia}"
PLANTS="${PLANTS:-single double}"
PROFILES="${PROFILES:-nominal mass bias dropout combined}"
SEEDS="${SEEDS:-96301 96302 96303 96304 96305}"
mkdir -p "$OUT"; OUT="$(cd "$OUT" && pwd)"
"$JULIA" --version
if [ ! -d "$OUT/bench/standard_benchmark" ]; then
  echo "Copying plant folders (without archived test/validation logs)..."
  for p in single double; do
    mkdir -p "$OUT/bench/standard_benchmark/$p"
    (cd "$SRC/$p" && tar cf - --exclude=./test --exclude=./validation --exclude=./smoke --exclude=./calibration --exclude=./guard_replay .) \
      | (cd "$OUT/bench/standard_benchmark/$p" && tar xf -)
  done
fi
for plant in $PLANTS; do
  P="$OUT/bench/standard_benchmark/$plant"
  "$JULIA" --startup-file=no --project="$P" -e 'using Pkg; Pkg.instantiate()'
  for seed in $SEEDS; do for profile in $PROFILES; do
    V="$OUT/$plant/${profile}_seed${seed}"
    [ -f "$V/DONE" ] && { echo "skip $plant $profile $seed"; continue; }
    rm -rf "$V"; mkdir -p "$V"
    # Private working copy of the plant folder (small; excludes logs) so each case has its own guard_replay.
    (cd "$P" && tar cf - --exclude=guard_replay --exclude=physics_models .) | (cd "$V" && tar xf -)
    echo "=== $plant $profile seed $seed : $(date)"
    "$JULIA" --startup-file=no --project="$P" "$HERE/replay_seed.jl" "$V" "$profile" "$seed" 2>&1 | tail -3
    "$JULIA" --startup-file=no --project="$P" "$HERE/run_study.jl" "$V" "$V/study" 2>&1 | tail -1
    "$JULIA" --startup-file=no --project="$P" "$HERE/extract_raw.jl" "$V" "$V/study" "$V/raw" 2>&1 | tail -1
    touch "$V/DONE"
  done; done
done
echo "Finished: $(date). Outputs in $OUT; pack them for the Python analysis with ../analysis/pack_seeds.py."
