# Single-column version of Fig. 2 (Double IP, seed 96301: dropout and combined), same data and encodings
# as plot_ip_readable.jl. Usage: julia plot_double_column.jl <folder containing double/test/*.csv> <output prefix>
using CairoMakie, DelimitedFiles
CairoMakie.activate!()
ROOT = abspath(ARGS[1]); out = ARGS[2]
TNR = "/System/Library/Fonts/Supplemental/Times New Roman.ttf"
TNRB = "/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf"
set_theme!(Theme(font=TNR, fonts=(regular=TNR, bold=TNRB), fontsize=7,
    Axis=(xgridcolor=(:gray, .2), ygridcolor=(:gray, .2), xgridwidth=.4, ygridwidth=.4,
          spinewidth=.6, titlefont=:regular, titlesize=7, xlabelsize=7, ylabelsize=7,
          xticklabelsize=6, yticklabelsize=6, xtickwidth=.6, ytickwidth=.6,
          xticksize=2.5, yticksize=2.5, titlegap=2, xlabelpadding=1, ylabelpadding=2)))
function raw(profile, method; seed=96301)
    p = joinpath(ROOT, "double", "test", "$(profile)_$(method)_seed$(seed).csv")
    names = split(readline(p), ','); a = readdlm(p, ','; skipstart=1)
    Dict(n => Float64.(a[:, j]) for (j, n) in enumerate(names))
end
cols = Dict(:neural_encoder => "#CC3978", :mm_binding => "#008C7C", :physics_only => "#686868", :oracle => "#111111")
labels = Dict(:neural_encoder => "Neural CF encoder", :mm_binding => "MM–CF binding", :physics_only => "Physics only", :oracle => "Oracle")
sy(y, s) = sign.(y) .* log10.(1 .+ abs.(y) ./ s)       # signed-log axis with physical-value ticks
tk(v) = [isinteger(x) ? string(round(Int, x)) : string(x) for x in v]
function events!(ax)
    vspan!(ax, 12, 12.4; color=(:gray, .13)); vlines!(ax, [8.]; color=(:gray, .8), linestyle=:dash, linewidth=.6)
    xlims!(ax, 0, 20); ax.xticks = 0:5:20; ax.xticklabelalign = (:center, :top)
end
f = Figure(size=(248, 258), figure_padding=(1, 4, 1, 1))   # 3.45 in wide at pt_per_unit = 1
ms = [:neural_encoder, :mm_binding, :physics_only, :oracle]
ta = [-1000., -12., 0., 12., 1000.]; tp = [-10., -.8, 0., .8, 10.]
for (j, profile) in enumerate(["dropout", "combined"])
    isfirst = j == 1
    ax = Axis(f[1, j], title="($(isfirst ? "a" : "b")) $(profile)", ylabel=isfirst ? "angle [deg]" : "",
              yticks=(sy(ta, 1.), tk(ta)))
    ay = Axis(f[2, j], ylabel=isfirst ? "cart [m]" : "", yticks=(sy(tp, .1), tk(tp)))
    au = Axis(f[3, j], xlabel="time [s]", ylabel=isfirst ? "force [N]" : "", yticks=[-10, 0, 10])
    for m in ms
        d = raw(profile, m); t = d["time"]
        lw = m == :oracle ? .7 : .8
        lines!(ax, t, sy(rad2deg.(d["x2"] .+ d["x3"]), 1.); color=cols[m], linewidth=lw, label=labels[m])
        lines!(ay, t, sy(d["x1"], .1); color=cols[m], linewidth=lw)
        lines!(au, t, d["u"]; color=cols[m], linewidth=.5)
    end
    hlines!(ax, sy([-12., 12.], 1.); color=:black, linestyle=:dash, linewidth=.6)
    hlines!(ay, sy([-.8, .8], .1); color=:black, linestyle=:dash, linewidth=.6)
    hlines!(au, [-9.5, 9.5]; color=:black, linestyle=:dash, linewidth=.6)
    ylims!(ax, sy(-1500., 1.), sy(1500., 1.)); ylims!(ay, sy(-12., .1), sy(12., .1)); ylims!(au, -11, 11)
    for aa in (ax, ay, au); events!(aa); end
    hidexdecorations!(ax; grid=false, ticks=false); hidexdecorations!(ay; grid=false, ticks=false)
    if !isfirst; hideydecorations!(ax; grid=false, ticks=false); hideydecorations!(ay; grid=false, ticks=false); hideydecorations!(au; grid=false, ticks=false); end
    if isfirst
        Legend(f[4, 1:2], ax; orientation=:horizontal, nbanks=2, framevisible=false, labelsize=6.5,
               patchsize=(12, 5), colgap=6, padding=(0, 0, 0, 0))
    end
end
colgap!(f.layout, 9); rowgap!(f.layout, 3); rowgap!(f.layout, 3, 2)
save(out * ".pdf", f; pt_per_unit=1); save(out * ".png", f; px_per_unit=4)
println("saved ", out, ".pdf/.png")
