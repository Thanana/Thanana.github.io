#!/bin/bash
# Regenerate Fig. 2 (Double IP, single column) in Julia from the archived test records.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
julia "$HERE/plot_double_column.jl" "$HERE/data" "$HERE/standard_double_profiles_column"
