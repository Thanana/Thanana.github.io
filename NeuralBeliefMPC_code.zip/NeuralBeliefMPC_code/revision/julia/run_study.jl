using LinearAlgebra,DelimitedFiles,Serialization,SHA,Printf
base=abspath(ARGS[1]);out=abspath(ARGS[2]);mkpath(out)
include(joinpath(base,"mpc_core.jl"))
include(joinpath(base,"neural_adaptation.jl"))
BLAS.set_num_threads(1)
nn=read_bundle();nphi=length(nn.phi);anchor=vcat(nn.anchor_phi,nn.anchor_theta)
nominal=parse(Float64,read(joinpath(base,"selected_radius.txt"),String))
gain=NP==1 ? 21.100612 : 79.946563
KM=Matrix{Float64}(readdlm(joinpath(base,"audit/K_MPC.csv"),','))
M=Matrix{Float64}(readdlm(joinpath(base,"audit/cell_M.csv"),','));bb=vec(readdlm(joinpath(base,"audit/cell_b.csv"),','))
den=vec(sqrt.(sum((M.*reshape(ZS[1:NX],1,:)).^2;dims=2)));nonzero=den.>0
readmat(p)=Matrix{Float64}(readdlm(p,','))
sha(p)=bytes2hex(sha256(read(p)))
manifest=Dict{String,String}()
for folder in ("models","audit")
 for path in readdir(joinpath(base,folder);join=true)
  isfile(path)&&endswith(path,".csv")&&(manifest[relpath(path,base)]=sha(path))
 end
end
for file in ["config.jl","neural_core.jl","neural_adaptation.jl","mpc_core.jl","plant_core.jl","Project.toml","Manifest.toml","selected_radius.txt"]
 manifest[file]=sha(joinpath(base,file))
end
function belief(v,r,rad)
 ctx=(features=vec(r["features"]),mean=vec(r["mean"]),cov=r["cov"],trust_radius=rad)
 encoded_belief(nn,ctx;phi=v[1:nphi])
end
function diagnostics(m0,P0,m1,P1)
 a=norm(m1[1:NX]-m0[1:NX]);b=norm(cholesky(Symmetric(P1[1:NX,1:NX])).L-cholesky(Symmetric(P0[1:NX,1:NX])).L)
 (sqrt(a*a+b*b),a,b)
end
function field(io,values);println(io,join(values,','));end
headers=["record","policy","uc_limit","ua_limit","available","radius","budget","reference_cell_radius","reference_cell_slack","accepted","trials","gate_rejections","selected_trial","score_before","score_after","parameter_step","coupling","update_mean_component","update_factor_component","reference_coupling","reference_mean_component","reference_factor_component","incumbent_cell_violation","final_cell_violation","correction_input","update_input","affine_pair_valid","mean_only_correction_input","mean_only_reference_mean_norm","joint_reference_mean_norm","factor_covariance_change"]
io=open(joinpath(out,"decisions.csv"),"w");println(io,join(headers,','))
trialio=open(joinpath(out,"trials.csv"),"w");println(trialio,"record,trial,score_before,score_after,parameter_step,score_pass")
cases=sort(filter(p->isdir(p)&&startswith(basename(p),"record_"),readdir(joinpath(base,"guard_replay");join=true)))
for (index,folder) in enumerate(cases)
 rec=basename(folder);r=Dict(splitext(basename(p))[1]=>readmat(p) for p in readdir(folder;join=true) if endswith(p,".csv"))
 for p in readdir(folder;join=true);isfile(p)&&(manifest[relpath(p,base)]=sha(p));end
 old=vec(r["old"]);nn.phi=copy(old[1:nphi]);nn.theta=copy(old[nphi+1:end])
 batch=(F=r["F"],M=r["M"],U=r["U"],Y=r["Y"],W=reshape(r["W"],NY,NY,:),Cdiag=r["Cdiag"],radii=r["radii"])
 before=cached_loss(nn,old,batch)
 gradient=Flux.gradient(v->cached_loss(nn,v,batch),old)[1];gradient[nphi+1:end].=0.
 gradient.*=min(1.,GRAD_LIMIT/max(norm(gradient),1e-30))
 delta=-ONLINE_ETA*gradient;delta.*=min(1.,EPS_JOINT/max(norm(delta),1e-30))
 dest=joinpath(out,rec);mkpath(dest);writedlm(joinpath(dest,"proposal.csv"),delta,',')
 candidates=[project_candidate(old+2.0^(-j)*delta,anchor) for j in 0:7]
 scores=[cached_loss(nn,v,batch) for v in candidates]
 pass=[isfinite(scores[j])&&scores[j]<=before-1e-4sum(abs2,candidates[j]-old)+1e-12 for j in 1:8]
 for j in 1:8;field(trialio,[rec,j,before,scores[j],norm(candidates[j]-old),Int(pass[j])]);end
 xr=ZS[1:NX].*vec(r["mean"])[1:NX];slack=bb-M*xr;cell=minimum(slack[nonzero]./den[nonzero]);inside=minimum(slack)>=0
 for uc in [.001,.01,.1],policy in ["fixed","correction_only","simultaneous"]
  ua=.1uc;available=policy=="fixed"||inside
  rad=policy=="fixed" ? nominal : (inside ? min(nominal,.99cell,uc/gain) : 0.)
  budget=policy=="simultaneous" ? min(.002,ua/gain) : .002
  m0,P0=belief(old,r,rad);selected=0;trials=0;rejects=0;m1=copy(m0);P1=copy(P0);after=before;step=0.
  if available
   for j in 1:8
    trials=j;mc,Pc=belief(candidates[j],r,rad);rho,_,_=diagnostics(m0,P0,mc,Pc)
    if rho>budget+1e-12;rejects+=1;continue;end
    if pass[j];selected=j;m1=mc;P1=Pc;after=scores[j];step=norm(candidates[j]-old);break;end
   end
  end
  coupling,dm,df=diagnostics(m0,P0,m1,P1);refcoupling,rm,rf=diagnostics(vec(r["mean"]),r["cov"],m1,P1)
  x0=ZS[1:NX].*m0[1:NX];x1=ZS[1:NX].*m1[1:NX]
  vi0=maximum(M*x0-bb);vi1=maximum(M*x1-bb)
  ci=only(abs.(KM*(x1-xr)));ui=only(abs.(KM*(x1-x0)))
  v=selected>0 ? candidates[selected] : old
  raw,_=neural_encoder(nn.re_phi(v[1:nphi]),r["features"],r["mean"],nn.emean,nn.escale)
  meanoffset=vec(raw)[1:NX]-vec(r["mean"])[1:NX];meanoffset.*=min(1.,rad/max(norm(meanoffset),1e-30))
  mi=only(abs.(KM*(ZS[1:NX].*meanoffset)))
  field(io,[rec,policy,uc,ua,Int(available),rad,budget,cell,minimum(slack),Int(selected>0),trials,rejects,selected,before,after,step,coupling,dm,df,refcoupling,rm,rf,vi0,vi1,ci,ui,Int(inside&&vi0<=1e-12&&vi1<=1e-12),mi,norm(meanoffset),rm,norm(P1[1:NX,1:NX]-r["cov"][1:NX,1:NX])])
 end
 index%10==0&&(println(basename(base),": ",index,"/",length(cases)," frozen contexts");flush(stdout);flush(io))
end
close(io);close(trialio)
open(joinpath(out,"source_hashes.tsv"),"w") do f
 for path in sort(collect(keys(manifest)));println(f,manifest[path],"\t",path);end
end
println("Finished ",basename(base),"; ",length(cases)," contexts, 3 tolerance pairs, 3 policies. No closed-loop simulation.")
