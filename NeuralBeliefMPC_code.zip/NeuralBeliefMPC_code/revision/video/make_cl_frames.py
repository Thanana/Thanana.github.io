# Render the closed-loop comparison (Double IP, mass profile, seed 96301, u_c=0.01 N) from saved logs.
import numpy as np,sys,os,matplotlib
matplotlib.use('Agg');import matplotlib.pyplot as plt
O=sys.argv[1];out=sys.argv[2];os.makedirs(out,exist_ok=True)
case=f'{O}/double/mass_seed96301'
runs=[('Original radial map',f'{case}/guard_replay/mass_mm_binding_seed96301.csv','#526070'),
      ('Scalar envelope $\\mathcal{S}_B$',f'{case}/closed_loop_scalar_uc0.01/mass_mm_binding_seed96301.csv','#2778c4'),
      ('Directional, $H=1$',f'{case}/closed_loop_dir1_uc0.01/mass_mm_binding_seed96301.csv','#e08a2a'),
      ('Directional, $H=N$ (plan-consistent)',f'{case}/closed_loop_dirN_uc0.01/mass_mm_binding_seed96301.csv','#c43c55')]
L=[np.genfromtxt(f,delimiter=',',names=True) for _,f,_ in runs]
first=[(a['time'][a['violation']>0][0] if (a['violation']>0).any() else None) for a in L]
plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'mathtext.fontset':'dejavuserif','font.size':15})
fps=30;T=20.0;nf=int(T*fps)
for f in range(nf):
    t=f/fps;k=min(int(round(t/0.02)),len(L[0])-1)
    fig=plt.figure(figsize=(19.2,12),dpi=100)
    fig.text(.5,.965,'Closed loop, Double IP, last-pole mass +50% at 8 s (seed 96301), $\\bar u_c=0.01$ N',ha='center',fontsize=24,color='#003791',weight='bold')
    fig.text(.5,.935,f't = {t:5.2f} s   (real time)',ha='center',fontsize=18,color='#202734')
    for i,((name,_,col),a) in enumerate(zip(runs,L)):
        ax=fig.add_axes([0.04+0.48*(i%2),0.53-0.33*(i//2)+0.0,0.44,0.36] if False else [0.04+0.48*(i%2),0.60-0.30*(i//2),0.44,0.30])
        kk=min(k,len(a)-1);p=a['x1'][kk];t1=a['x2'][kk];t2=t1+a['x3'][kk]
        ax.set_xlim(-2.4,2.4);ax.set_ylim(-2.1,2.75);ax.set_aspect('equal');ax.axis('off')
        ax.plot([-2.2,2.2],[0,0],color='#999',lw=2)
        for xl in (-0.8,0.8):ax.plot([xl,xl],[-0.15,0.15],color='#c43c55',lw=2,ls='--')
        ax.add_patch(plt.Rectangle((p-0.2,-0.1),0.4,0.2,color=col))
        x1,y1=p+np.sin(t1),np.cos(t1);x2,y2=x1+np.sin(t2),y1+np.cos(t2)
        ax.plot([p,x1,x2],[0,y1,y2],color=col,lw=5,solid_capstyle='round');ax.plot([x1],[y1],'o',color='#202734',ms=6)
        v=first[i];status='within limits' if (v is None or t<v) else f'limit violated at {v:.2f} s'
        ax.text(0,2.62,name,ha='center',fontsize=19,weight='bold',color=col)
        ax.text(0,2.32,status,ha='center',fontsize=16,color=('#1b7a3a' if status=='within limits' else '#c43c55'))
    ax=fig.add_axes([0.07,0.05,0.88,0.17])
    for (name,_,col),a in zip(runs,L):
        m=a['time']<=t+1e-9;ax.plot(a['time'][m],a['x1'][m],color=col,lw=2.2)
    ax.axhline(0.8,color='#c43c55',ls='--',lw=1);ax.axhline(-0.8,color='#c43c55',ls='--',lw=1);ax.axvline(8,color='gray',ls=':',lw=1.2)
    ax.set_xlim(0,20);ax.set_ylim(-2.2,2.2);ax.set_ylabel('cart position [m]');ax.set_xlabel('time [s]');ax.grid(alpha=.3)
    for s in ('top','right'):ax.spines[s].set_visible(False)
    fig.savefig(f'{out}/f{f:04d}.png');plt.close(fig)
print('frames',nf,'first violations',first)
