"""Supplementary Video S1 for the v5 manuscript.
Parts: new title card; the original saved Double-IP dropout replay (seconds 6-46 of the source video, frames copied
unchanged); a closed-loop comparison of deployed belief corrections rendered from saved logs; a results card; a new end card.
No simulation, observer, controller or training is rerun by this script."""
from PIL import Image,ImageDraw,ImageFont
import subprocess,json,hashlib,sys,os
from pathlib import Path
SRC=Path(sys.argv[1]);FR=Path(sys.argv[2]);OUT=Path(sys.argv[3]).resolve();OUT.mkdir(parents=True,exist_ok=True);W_=OUT/'build';W_.mkdir(exist_ok=True)
W,H=1920,1200;BLUE='#003791';GRAY='#526070';BLACK='#202734';RED='#c43c55'
F='/usr/share/fonts/truetype/liberation/LiberationSerif-'
font=lambda s,b=False:ImageFont.truetype(F+('Bold' if b else 'Regular')+'.ttf',s)
def base(label):
    im=Image.new('RGB',(W,H),'white');d=ImageDraw.Draw(im);d.line((80,72,W-80,72),fill=BLUE,width=6);center(d,140,label,30,color=GRAY);return im,d
def center(d,y,t,s=36,b=False,color=BLUE):
    f=font(s,b);bb=d.textbbox((0,0),t,font=f);assert bb[2]-bb[0]<W-160,t;d.text(((W-(bb[2]-bb[0]))/2,y),t,font=f,fill=color)
TITLE=['Neural Belief Corrections for MPC:','Plan-Consistent Scalar Budgets versus','Myopic Directional Constraints']
im,d=base('TECHNICAL NOTE  |  SUPPLEMENTARY VIDEO S1')
for i,l in enumerate(TITLE):center(d,235+78*i,l,62,True)
center(d,505,'Prepared for IEEE Transactions on Automatic Control',34)
center(d,640,'Part 1   Saved Double-IP replay: angle dropout, test seed 96301, playback 0.5x',32,color=BLACK)
center(d,705,'Part 2   Closed-loop comparison of deployed belief corrections, mass change, real time',32,color=BLACK)
center(d,770,'Part 3   Summary of 300 closed-loop runs and 4633 frozen contexts',32,color=BLACK)
center(d,935,'Schematic animations rendered from saved simulation logs',30,color=GRAY)
im.save(W_/'opening.png')
im,d=base('PART 2  |  CLOSED-LOOP COMPARISON OF DEPLOYED BELIEF CORRECTIONS')
center(d,250,'Same observer, same episode, four deployed belief means',50,True)
center(d,380,'Original radial map: the MM-CF binding observer of the 600-episode study',32,color=BLACK)
center(d,440,'Scalar envelope S_B: radius set by the input tolerance (Corollary 1, Theorem 3)',32,color=BLACK)
center(d,500,'Directional H = 1: constrains only the applied input',32,color=BLACK)
center(d,560,'Directional H = N: constrains all 50 predicted inputs (plan-consistent)',32,color=BLACK)
center(d,700,'Double IP, last-pole mass +50% at 8 s, test seed 96301, input tolerance 0.01 N',32,color=GRAY)
center(d,760,'Adaptation, cached score and coupling gate are unchanged in all four runs',32,color=GRAY)
center(d,900,'Proposition 3: corrections hidden from the applied input reappear in later inputs and states',32,True)
im.save(W_/'intro2.png')
im,d=base('PART 3  |  SUMMARY  (TABLES III-IV AND SUPPLEMENT S4-S5)')
center(d,225,'Plan consistency does not imply safe deployment',52,True)
center(d,345,'Closed loop, Double IP, 25 episodes, input tolerance 0.001 / 0.01 N: zero-violation episodes',32,color=BLACK)
for y,(a,b) in zip([420,480,540,600],[('Original radial map','17 / 17'),('Scalar envelope','16 / 17'),('Directional, H = 1','9 / 8'),('Directional, H = N','1 / 2')]):
    d.text((640,y),a,font=font(38),fill=BLACK);d.text((1180,y),b,font=font(38),fill=BLACK)
center(d,700,'Single IP: all four keep 25/25 episodes safe with unchanged tracking',32,color=GRAY)
center(d,790,'4633 frozen contexts: directional sets retain more of the raw proposal (Double IP 9.7-33.7% median),',30,color=BLACK)
center(d,840,'but are farther from the true state in 59-64% of contexts',30,color=BLACK)
center(d,960,'The scalar rule trades tracking for certified input tolerances; its conservatism is protective here',30,True)
im.save(W_/'summary.png')
im,d=base('TECHNICAL NOTE  |  END OF SUPPLEMENTARY VIDEO S1')
center(d,250,'Scope of this video',58,True)
center(d,400,'Part 1 replays the original saved Double-IP experiment (Table II, Fig. 2)',34,color=BLACK)
center(d,465,'Part 2 renders saved logs of the closed-loop postprocessor runs (Table IV, Supplement S5)',34,color=BLACK)
center(d,600,'Observer budgets and plan consistency do not certify physical safety',40,True)
center(d,700,'No simulation or training was rerun to create this video',30,color=GRAY)
center(d,900,'Neural Belief Corrections for MPC  |  Supplementary Video S1',30,color=BLUE)
im.save(W_/'ending.png')
def run(cmd,log):
    with open(W_/log,'w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
enc=['-an','-c:v','libx264','-preset','fast','-crf','22','-profile:v','high','-level:v','5.0','-pix_fmt','yuv420p','-r','30']
for n,s in [('opening',8),('intro2',8),('summary',12),('ending',6)]:
    run(['ffmpeg','-y','-v','warning','-loop','1','-framerate','30','-i',str(W_/(n+'.png')),'-frames:v',str(30*s)]+enc+[str(W_/(n+'.mp4'))],n+'.log')
run(['ffmpeg','-y','-v','warning','-framerate','30','-i',str(FR/'f%04d.png'),'-vf','scale=1920:1200']+enc+[str(W_/'anim.mp4')],'anim.log')
run(['ffmpeg','-y','-v','warning','-ss','6','-i',str(SRC),'-frames:v','1200','-an','-c:v','copy',str(W_/'replay.mp4')],'replay.log')
(W_/'concat.txt').write_text(''.join(f"file '{W_/n}.mp4'\n" for n in ['opening','replay','intro2','anim','summary','ending']))
MOVIE=OUT/'TAC_TN_Supplementary_Video_S1.mp4'
run(['ffmpeg','-y','-v','warning','-f','concat','-safe','0','-i',str(W_/'concat.txt')]+enc+['-movflags','+faststart','-metadata','title=Neural Belief Corrections for MPC - Supplementary Video S1',str(MOVIE)],'concat.log')
pr=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,nb_frames,duration,r_frame_rate','-of','json',str(MOVIE)]))['streams'][0]
run(['ffmpeg','-v','error','-i',str(MOVIE),'-f','null','-'],'decode.log')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
man={'movie':MOVIE.name,'stream':pr,'timeline_seconds':{'opening':[0,8],'part1_saved_replay':[8,48],'part2_intro':[48,56],'part2_closed_loop_animation':[56,76],'part3_summary':[76,88],'ending':[88,94]},
     'source_replay_video':str(SRC),'source_replay_sha256':sha(SRC),'closed_loop_case':'double, mass profile, seed 96301, u_c=0.01 N; logs in output/double/mass_seed96301 (regenerate with julia/closed_loop/run_closed_loop.sh)',
     'simulation_or_training_rerun_for_video':False,'author_names_displayed':False,'full_decode_check':'passed','movie_sha256':sha(MOVIE)}
(OUT/'video_manifest.json').write_text(json.dumps(man,indent=2)+'\n');print(json.dumps(pr))
