# Independent certificate on a random sample of the pooled study: tighter Clarabel re-solve,
# NNLS multipliers on the near-active set, exact weak-duality lower bound -> certified distance gap.
import numpy as np,sys,glob,os,cvxpy as cp,warnings;warnings.filterwarnings('ignore')
from scipy.optimize import nnls
S=sys.argv[1];KUdir=sys.argv[2];nsamp=int(sys.argv[3]);rng=np.random.default_rng(20261016)
GAIN={'single':21.100612,'double':79.946563};eps=.002;N=50;sc=1/eps
for plant,npole in [('single',1),('double',2)]:
    nx=2*(npole+1);s=np.r_[.75,np.full(npole,np.deg2rad(11)),np.ones(npole+1)];GU=-np.load(f'{KUdir}/{plant}/KU.npy')*s;g=GAIN[plant]
    M=np.loadtxt(f'{S}/{plant}__cell_M.csv',delimiter=',');b=np.loadtxt(f'{S}/{plant}__cell_b.csv',delimiter=',').ravel()
    R=float(open(f'{S}/{plant}__selected_radius.txt').read());A=M*s;den=np.linalg.norm(A,axis=1);nz=den>0
    items=[(f,i) for f in sorted(glob.glob(f'{S}/{plant}__*_seed*.npz')) for i in range(len(np.load(f)['mean']))]
    pick=[items[j] for j in rng.choice(len(items),nsamp,replace=False)];worst={};cnt=0
    for f,i in pick:
        Z=np.load(f);mean=Z['mean'][i];qold,q=Z['raw'][i][:,0],Z['raw'][i][:,1];slack=b-M@(s*mean)
        if min(slack)<0:continue
        rcell=min(slack[nz]/den[nz]);rhs=.99*slack[nz]/(R*den[nz]);hs=A[nz]/den[nz,None];act=rhs<1;Hf=hs[act];hf=rhs[act];cnt+=1
        for uc in [.001,.01,.1]:
            ua=.1*uc;r=min(R,.99*rcell,uc/g);d0=qold*min(1,r/max(np.linalg.norm(qold),1e-300))
            for H in [1,N]:
                for pol in ['scalar','dir']:
                    G=GU[:H];gn=np.linalg.norm(G[0]);Gs=G/gn;x=cp.Variable(nx)
                    balls=[(sc*d0,1.),(np.zeros(nx),sc*(r if pol=='scalar' else R))]
                    lin=[(Gs,sc*ua/gn+Gs@(sc*d0)),(-Gs,sc*ua/gn-Gs@(sc*d0))]
                    if pol!='scalar':
                        lin+=[(Gs,np.full(H,sc*uc/gn)),(-Gs,np.full(H,sc*uc/gn))]
                        if len(hf):lin.append((Hf,hf*sc*R))
                    cons=[cp.norm(x-c)<=rr for c,rr in balls]+[Am@x<=bb for Am,bb in lin]
                    cp.Problem(cp.Minimize(cp.sum_squares(x-sc*q)),cons).solve(solver=cp.CLARABEL,tol_gap_abs=1e-13,tol_gap_rel=1e-13,tol_feas=1e-13,max_iter=1000)
                    xv=x.value;cols=[];tags=[]
                    for j,(c,rr) in enumerate(balls):
                        if rr-np.linalg.norm(xv-c)<=1e-6*max(rr,1):cols.append(2*(xv-c));tags.append(('b',j,0))
                    for j,(Am,bb) in enumerate(lin):
                        for k in np.where(bb-Am@xv<=1e-6*max(1,np.max(np.abs(bb))))[0]:cols.append(Am[k]);tags.append(('l',j,k))
                    mus=[0.]*2;lam=[np.zeros(Am.shape[0]) for Am,_ in lin]
                    if cols:
                        sol,_=nnls(np.array(cols).T,-2*(xv-sc*q))
                        for v,(kd,j,k) in zip(sol,tags):
                            if kd=='b':mus[j]=v
                            else:lam[j][k]=v
                    xs=(sc*q+sum(m*c for m,(c,_) in zip(mus,balls))-.5*sum(Am.T@l for l,(Am,_) in zip(lam,lin)))/(1+sum(mus))
                    LB=np.sum((xs-sc*q)**2)+sum(m*(np.sum((xs-c)**2)-rr*rr) for m,(c,rr) in zip(mus,balls))+sum(l@(Am@xs-bb) for l,(Am,bb) in zip(lam,lin))
                    pv=np.sum((xv-sc*q)**2);gap=(np.sqrt(pv)-np.sqrt(max(LB,0)))/sc;rel=gap/max(np.sqrt(pv)/sc,1e-12)
                    feas=max(max(np.linalg.norm(xv-c)-rr for c,rr in balls),max(np.max(Am@xv-bb) for Am,bb in lin))/sc
                    key=(H,pol);w=worst.get(key,(0,0,-1));worst[key]=(max(w[0],gap),max(w[1],rel if np.sqrt(pv)/sc>1e-6 else 0),max(w[2],feas))
    for k,v in sorted(worst.items()):print(plant,'contexts',cnt,'H',k[0],k[1],'max certified distance gap %.1e  max relative gap (dist>1e-6) %.1e  max primal violation %.1e'%v)
