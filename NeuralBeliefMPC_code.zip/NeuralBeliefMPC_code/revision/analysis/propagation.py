# Proposition 2(b)-(c) constants for the Double IP (Sec. V-C): gamma_k, gamma^(j), sigma_j, ||Psi_j||,
# and the median lower bounds of (22)-(23) at u_c = 0.001 N from the pooled results.
# Usage: python3 propagation.py <standard_benchmark> <KU dir> <seed_study_results.csv.gz>
import numpy as np,sys,csv,gzip,statistics as st
B0,KUdir,res=sys.argv[1:4]; plant,npole='double',2
s=np.r_[.75,np.full(npole,np.deg2rad(11)),np.ones(npole+1)];Sx=np.diag(s)
d=f'{B0}/{plant}/audit/';A=np.loadtxt(d+'A.csv',delimiter=',');B=np.loadtxt(d+'B.csv',delimiter=',').reshape(-1,1)
KM=np.loadtxt(d+'K_MPC.csv',delimiter=',').reshape(1,-1);F=A-B@KM
G=-KM@Sx;P1=G.T@G/(G@G.T);Q=np.eye(len(s))-P1
GU=-np.load(f'{KUdir}/{plant}/KU.npy')*s
gk=[np.linalg.norm(Q@GU[k]) for k in range(GU.shape[0])]
print('gamma_1 = %.2f, max_k gamma_k = %.2f at k = %d'%(gk[1],max(gk),int(np.argmax(gk))))
gj=[];sj=[];pj=[]
for j in range(1,51):
    Fj=np.linalg.matrix_power(F,j);Aj=np.linalg.matrix_power(A,j)
    gj.append(np.linalg.norm(Q@(-KM@Fj@Sx).ravel()));Psi=(Fj-Aj)@Sx
    Pn=np.linalg.inv(Sx)@Psi   # normalized state change, as reported in the paper
    sj.append(np.linalg.norm(Pn@Q,2));pj.append(np.linalg.norm(Pn,2))
print('max_j gamma^(j) = %.2f at j = %d'%(max(gj),int(np.argmax(gj))+1))
print('normalized: sigma_25 = %.1f, ||S_x^-1 Psi_25|| = %.1f'%(sj[24],pj[24]))
R=[r for r in csv.DictReader(gzip.open(res,'rt')) if r['plant']==plant and r['uc']=='0.001' and r['inside']=='1']
lb=[float(r['lb_plan']) for r in R]
print('median bound (22) = %.1f u_c (lb_plan)'%st.median(lb))
root=st.median([float(r['lb_plan'])*0.001/max(gk) for r in R])
print('median normalized state-deviation bound sigma_25*sqrt(t*^2-delta_s^2) = %.3f; scalar cap ||Psi_25||*u_c/g = %.1e'%(sj[24]*root,pj[24]*0.001/79.946563))
