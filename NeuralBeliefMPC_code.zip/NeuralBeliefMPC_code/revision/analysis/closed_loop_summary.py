import csv,glob,os,sys,re,numpy as np
O=sys.argv[1];rows=[]
for f in glob.glob(f'{O}/*/*/closed_loop_*_uc*/summary_*.csv'):
    rows+=list(csv.DictReader(open(f)))
base={}
for f in glob.glob(f'{O}/*/*_seed*/guard_replay/summary.txt'):
    s=open(f).read();plant=f.split('/')[-4];case=f.split('/')[-3]
    g=lambda k:re.search(k+r' = ([^,\)]+)',s).group(1)
    base[(plant,case)]=dict(zero_violation=g('zero_violation')=='true',track=float(g('angle_tracking_rmse_deg')),est=float(g('angle_estimation_rmse_deg')))
print('closed-loop summaries:',len(rows))
for plant in ['single','double']:
    for uc in ['0.001','0.01']:
        R=[r for r in rows if r['plant']==plant and r['uc']==uc]
        if not R:continue
        cases=sorted({(r['profile'],r['seed']) for r in R})
        b=[base[(plant,f'{p}_seed{s}')] for p,s in cases if (plant,f'{p}_seed{s}') in base]
        print(f'== {plant} uc={uc}: episodes {len(cases)} | original MM-CF binding: ZV {sum(x["zero_violation"] for x in b)}/{len(b)} track med {np.median([x["track"] for x in b]):.2f} est med {np.median([x["est"] for x in b]):.3f}')
        for pol in ['scalar','dir1','dirN']:
            P=[r for r in R if r['policy']==pol]
            if not P:continue
            f=lambda k:np.array([float(r[k]) for r in P])
            zv=sum(r['zero_violation']=='true' for r in P)
            print(f'   {pol:6s} n={len(P)} ZV {zv}/{len(P)} complete {sum(r["complete"]=="true" for r in P)} | track med {np.median(f("angle_tracking_rmse_deg")):.2f} est med {np.median(f("angle_estimation_rmse_deg")):.3f} | plan max {f("max_plan_over_uc").max():.2f} median-of-medians {np.median(f("median_plan_over_uc")):.2f} | viol {f("max_constraint_violation").max():.1e} | fallback ticks med {np.median(f("fallback_ticks")):.0f} | sec med {np.median(f("seconds")):.0f}')
            byprof={}
            for r in P: byprof.setdefault(r['profile'],[]).append(r['zero_violation']=='true')
            print('      ZV by profile:',{k:f'{sum(v)}/{len(v)}' for k,v in sorted(byprof.items())})
