# Pack only what the projection analysis needs from the replay output folder (small npz per case). Usage: python3 pack_seeds.py <OUT of run_all.sh> <pack folder>.
import numpy as np,os,sys,glob
O=sys.argv[1];out=sys.argv[2];os.makedirs(out,exist_ok=True)
for plant in ['single','double']:
    nx=4 if plant=='single' else 6
    for case in sorted(glob.glob(f'{O}/{plant}/*')):
        if not os.path.exists(case+'/DONE'):continue
        name=os.path.basename(case);logf=glob.glob(case+'/guard_replay/*_mm_binding_seed*.csv')[0]
        a=np.genfromtxt(logf,delimiter=',',names=True)
        recs=sorted(glob.glob(case+'/raw/record_*'))
        mean=np.array([np.loadtxt(case+f'/guard_replay/{os.path.basename(r)}/mean.csv',delimiter=',').ravel()[:nx] for r in recs])
        raw=np.array([np.loadtxt(r+'/raw.csv',delimiter=',') for r in recs])
        X=np.vstack([a[f'x{j+1}'] for j in range(nx)]).T;Rf=np.vstack([a[f'reference{j+1}'] for j in range(nx)]).T
        np.savez_compressed(f'{out}/{plant}__{name}.npz',mean=mean,raw=raw,time=a['time'],X=X,Ref=Rf,viol=a['violation'])
    base=f'{O}/bench/standard_benchmark/{plant}'
    for f in ['audit/cell_M.csv','audit/cell_b.csv','audit/K_MPC.csv','selected_radius.txt']:
        os.system(f'cp "{base}/{f}" "{out}/{plant}__{os.path.basename(f)}"')
print(len(glob.glob(out+'/*.npz')),'cases packed')
