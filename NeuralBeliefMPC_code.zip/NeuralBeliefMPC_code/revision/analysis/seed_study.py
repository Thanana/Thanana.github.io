# Pooled frozen-context study over all replayed (profile, seed) episodes.
# Rebuilds problem data exactly as run_projection_study.py (radius, incumbent, cell facets), then solves
# scalar/directional projections for H=1 and H=N with Clarabel, and evaluates plan inputs and true error.
import numpy as np,sys,glob,os,csv,cvxpy as cp,warnings;warnings.filterwarnings('ignore')
S=sys.argv[1];KUdir=sys.argv[2];out=sys.argv[3]
GAIN={'single':21.100612,'double':79.946563};eps=.002;N=50
def solve(q,d0,rad,ucf,ua,G,Hf,hf,R0,scalar):
    sc=1/eps;gn=np.linalg.norm(G[0]);x=cp.Variable(len(q));Gs=G/gn
    cons=[cp.norm(x-sc*d0)<=1.,cp.abs(Gs@(x-sc*d0))<=sc*ua/gn]
    if scalar:cons.append(cp.norm(x)<=sc*rad)
    else:
        cons+=[cp.norm(x)<=sc*R0,cp.abs(Gs@x)<=sc*ucf/gn]
        if len(hf):cons.append(Hf@x<=hf*sc*R0)
    pr=cp.Problem(cp.Minimize(cp.sum_squares(x-sc*q)),cons)
    pr.solve(solver=cp.CLARABEL,tol_gap_abs=1e-12,tol_gap_rel=1e-12,tol_feas=1e-12,max_iter=500)
    return x.value/sc,pr.status
rows=[]
for plant,npole in [('single',1),('double',2)]:
    nx=2*(npole+1);s=np.r_[.75,np.full(npole,np.deg2rad(11)),np.ones(npole+1)]
    GU=-np.load(f'{KUdir}/{plant}/KU.npy')*s;g=GAIN[plant]
    M=np.loadtxt(f'{S}/{plant}__cell_M.csv',delimiter=',');b=np.loadtxt(f'{S}/{plant}__cell_b.csv',delimiter=',').ravel()
    KM=np.loadtxt(f'{S}/{plant}__K_MPC.csv',delimiter=',').ravel();assert np.allclose(GU[0],KM*s,atol=1e-9)
    R=float(open(f'{S}/{plant}__selected_radius.txt').read());A=M*s;den=np.linalg.norm(A,axis=1);nz=den>0
    ker=np.linalg.svd(GU[:1])[2][1:].T;gam=np.linalg.norm(GU@ker,axis=1)
    for f in sorted(glob.glob(f'{S}/{plant}__*.npz')):
        case=os.path.basename(f)[len(plant)+2:-4];profile,seed=case.split('_seed');Z=np.load(f)
        for i in range(len(Z['mean'])):
            mean=Z['mean'][i];qold,q=Z['raw'][i][:,0],Z['raw'][i][:,1]
            slack=b-M@(s*mean);k=int(np.argmin(np.max(np.abs(Z['Ref']-s*mean),1)))
            refmatch=float(np.max(np.abs(Z['Ref'][k]-s*mean)));et=Z['X'][k]/s-mean
            base=dict(plant=plant,profile=profile,seed=int(seed),record=i+1,time=float(Z['time'][k]),refmatch=refmatch,inside=int(min(slack)>=0))
            if min(slack)<0:
                rows.append(base);continue
            rcell=min(slack[nz]/den[nz]);rhs=.99*slack[nz]/(R*den[nz]);hs=A[nz]/den[nz,None];act=rhs<1;Hf=hs[act];hf=rhs[act]
            for uc in [.001,.01,.1]:
                ua=.1*uc;r=min(R,.99*rcell,uc/g);d0=qold*min(1,r/max(np.linalg.norm(qold),1e-300))
                tstar=min(R,.99*rcell,eps-np.linalg.norm(d0))
                row=dict(base,uc=uc,rs=r,ref_err=np.linalg.norm(et),raw_err=np.linalg.norm(q-et),
                         lb_plan=gam.max()*np.sqrt(max(tstar**2-r**2,0))/uc)
                for H in [1,N]:
                    for pol in ['scalar','dir']:
                        v,st=solve(q,d0,r,uc,ua,GU[:H],Hf,hf,R,pol=='scalar');key=f'{pol}H{H}'
                        row[key+'_dist']=np.linalg.norm(v-q);row[key+'_err']=np.linalg.norm(v-et);row[key+'_status']=st
                        row[key+'_planc']=np.max(np.abs(GU@v))/uc;row[key+'_planu']=np.max(np.abs(GU@(v-d0)))/ua
                        row[key+'_viol']=max(np.linalg.norm(v-d0)-eps,np.max(np.abs(GU[:H]@(v-d0)))-ua,(np.linalg.norm(v)-r) if pol=='scalar' else max(np.linalg.norm(v)-R,np.max(np.abs(GU[:H]@v))-uc,np.max(Hf@(v/R)-hf) if len(hf) else -1))
                rows.append(row)
        print(plant,case,flush=True)
keys=[];[keys.append(k) for r in rows for k in r if k not in keys]
with open(out,'w') as fo:
    w=csv.DictWriter(fo,fieldnames=keys,restval='');w.writeheader();w.writerows(rows)
print('rows',len(rows))
