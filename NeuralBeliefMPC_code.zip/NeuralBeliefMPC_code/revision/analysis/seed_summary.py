import csv,numpy as np,sys,math
R=list(csv.DictReader(open(sys.argv[1])))
up=lambda x,d:math.ceil(x*10**d-1e-9)/10**d
F=lambda rs,k:np.array([float(r[k]) for r in rs])
for plant in ['single','double']:
    allc=[r for r in R if r['plant']==plant];ctx={(r['profile'],r['seed'],r['record']) for r in allc}
    ins={(r['profile'],r['seed'],r['record']) for r in allc if r['inside']=='1'}
    print(f'== {plant}: contexts {len(ctx)}, in-cell {len(ins)}, refmatch max {max(float(r["refmatch"]) for r in allc):.1e}')
    for prof in ['nominal','mass','bias','dropout','combined']:
        c={k for k in ctx if k[0]==prof};i={k for k in ins if k[0]==prof};print(f'   {prof}: {len(i)}/{len(c)} in-cell')
    for uc in [.001,.01,.1]:
        rs=[r for r in allc if r['inside']=='1' and float(r['uc'])==uc]
        s1,d1,sN,dN=F(rs,'scalarH1_dist'),F(rs,'dirH1_dist'),F(rs,'scalarH50_dist'),F(rs,'dirH50_dist')
        thr=1e-7*(1e-4 if plant=='single' else 1e-2)
        pos=s1>0
        red1=100*(s1-d1)[pos]/s1[pos];redN=100*(sN-dN)[pos]/sN[pos]
        viol=max(F(rs,f'{p}H{h}_viol').max() for p in ['scalar','dir'] for h in [1,50])
        st={r[f'{p}H{h}_status'] for r in rs for p in ['scalar','dir'] for h in [1,50]}
        e1=F(rs,'dirH1_err')-F(rs,'scalarH1_err');eN=F(rs,'dirH50_err')-F(rs,'scalarH50_err')
        print(f' uc={uc} n={len(rs)} zero-scalar-dist {int(np.sum(~pos))} | red1 med {np.median(red1):.2f} IQR [{np.percentile(red1,25):.2f},{np.percentile(red1,75):.2f}] imp1 {int(np.sum(s1-d1>thr))}'
              f' | plan1 c max {up(F(rs,"dirH1_planc").max(),2)} med {np.median(F(rs,"dirH1_planc")):.2f} u max {up(F(rs,"dirH1_planu").max(),2)} | LB med {np.median(F(rs,"lb_plan")):.2f}'
              f' | redN med {np.median(redN):.2f} IQR [{np.percentile(redN,25):.2f},{np.percentile(redN,75):.2f}] impN {int(np.sum(sN-dN>thr))} planN c max {up(F(rs,"dirH50_planc").max(),4)} u max {up(F(rs,"dirH50_planu").max(),4)}'
              f' | scal plan c max {up(max(F(rs,"scalarH1_planc").max(),F(rs,"scalarH50_planc").max()),4)} u max {up(max(F(rs,"scalarH1_planu").max(),F(rs,"scalarH50_planu").max()),4)}'
              f' | err: dir1 worse {int(np.sum(e1>1e-12))} better {int(np.sum(e1<-1e-12))} med {np.median(e1):+.1e}; dirN worse {int(np.sum(eN>1e-12))} better {int(np.sum(eN<-1e-12))} med {np.median(eN):+.1e}'
              f' | raw<ref {int(np.sum(F(rs,"raw_err")<F(rs,"ref_err")))} med raw {np.median(F(rs,"raw_err")):.4f} ref {np.median(F(rs,"ref_err")):.4f} | viol {viol:.1e} status {st}')
