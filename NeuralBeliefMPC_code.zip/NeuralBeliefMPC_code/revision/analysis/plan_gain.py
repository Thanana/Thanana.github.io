import numpy as np,sys
B0=sys.argv[1]
def KU(plant,npole,N=50):
    d=f'{B0}/{plant}/results_mpc/';A=np.loadtxt(d+'A.csv',delimiter=',');B=np.loadtxt(d+'B.csv',delimiter=',').reshape(-1,1)
    K=np.loadtxt(d+'K.csv',delimiter=',').reshape(1,-1);P=np.loadtxt(d+'P.csv',delimiter=',')
    NY=npole+1;NX=2*NY;AB=np.eye(NX)
    for j in range(1,NY):AB[j,1:j+1]=1;AB[NY+j,NY+1:NY+j+1]=1
    Q=AB.T@np.diag(np.r_[10,np.full(npole,100.),1,np.full(npole,5.)])@AB;R=.2
    F=A-B@K;nx=NX*(N+1);Sx=np.zeros((nx,NX));Tx=np.zeros((nx,N));Sx[:NX]=np.eye(NX)
    for j in range(1,N+1):
        p=slice(NX*(j-1),NX*j);q=slice(NX*j,NX*(j+1));Sx[q]=F@Sx[p];Tx[q]=F@Tx[p];Tx[q,j-1]=B[:,0]
    Su=np.zeros((N,NX));Tu=np.eye(N)
    for j in range(N):
        ix=slice(NX*j,NX*(j+1));Su[j]=-(K@Sx[ix])[0];Tu[j]-=(K@Tx[ix])[0]
    W=np.zeros((nx,nx))
    for j in range(N):ix=slice(NX*j,NX*(j+1));W[ix,ix]=Q
    W[NX*N:,NX*N:]=P
    G=2*(Tx.T@W@Tx+R*Tu.T@Tu);qo=2*(Tx.T@W@Sx+R*Tu.T@Su)
    return Su-Tu@np.linalg.solve(G,qo),A,B   # U = KUfull @ x  (sign included)
for plant,npole in [('single',1),('double',2)]:
    U,A,B=KU(plant,npole);KM=np.loadtxt(f'{B0}/{plant}/audit/K_MPC.csv',delimiter=',').ravel()
    s=np.r_[.75,np.full(npole,np.deg2rad(11)),np.ones(npole+1)]
    print(plant,'first-row vs audit K_MPC: maxdiff(+)',np.max(np.abs(U[0]-KM)),'maxdiff(-)',np.max(np.abs(U[0]+KM)))
    GU=U*s;sv=np.linalg.svd(GU,compute_uv=False);print(' sigma(G_U)=',np.round(sv,4),' ||G||=',np.linalg.norm(GU[0]))
    np.save(f'{B0}/{plant}/KU.npy',U)
