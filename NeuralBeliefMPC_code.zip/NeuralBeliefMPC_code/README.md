# Code for "Neural Belief Corrections for MPC: Plan-Consistent Scalar Budgets versus Myopic Directional Constraints"

T. Nuchkrua, S. Boonto, W. Kornmaneesang, and X. Liu. Project page: https://thanana.github.io/NeuralBeliefMPC.html
Contact: Sudchai Boonto (sudchai.boo@kmutt.ac.th), Thanana Nuchkrua (thanana.nuch@yahoo.com).

Simulations, observers and MPC run in Julia 1.12.1. Post hoc analysis uses Python 3.12
(NumPy, SciPy, CVXPY with Clarabel). Tested on macOS (Apple silicon).

## Contents

| Folder | What it is |
|---|---|
| `standard_benchmark/single`, `standard_benchmark/double` | Pinned Julia environments (`Project.toml`, `Manifest.toml`), trained checkpoints, MPC data and certificates of the single and double inverted pendulum; `PROTOCOL.md` gives the full protocol |
| `revision/julia/` | Replay of 2 plants x 5 profiles x 5 seeds and frozen-context extraction (`run_all.sh`); closed-loop deployment of the remapped corrections (`closed_loop/`); Fig. 2 (`single_figure/`, Single-IP observer budgets, with its three test records) and Fig. 3 (`double_figure/`, Double-IP profiles, with its eight test records) |
| `revision/analysis/` | Pooled projection study, summaries, numerical primal-dual checks and Proposition 2 constants (Python) |
| `revision/analysis/inputs/` | Packed frozen contexts of the 50 replays (`seedpack.tgz`) and predicted-input maps (`KU/`) |
| `revision/analysis/results/` | Every pooled context (`seed_study_results.csv.gz`) and every closed-loop run (`closed_loop_results.csv`) |
| `revision/video/` | Scripts that assemble Supplementary Video S1 from saved logs |

Raw per-tick records of all 600 pendulum episodes are available from the authors on request.

## 1. Replay and frozen contexts (Sec. V-C)

```sh
cd revision/julia
bash run_all.sh                                  # 50 episodes, about 1 min each
SEEDS=96301 PROFILES=combined bash run_all.sh    # quick check
```

The scripts work on a copy of `standard_benchmark/` and write to `revision/output/`.

## 2. Pooled study (Table III) and Proposition 2 constants

```sh
cd revision/analysis
tar xzf inputs/seedpack.tgz                      # or: python3 pack_seeds.py ../output seedpack
python3 seed_study.py seedpack inputs/KU results/seed_study_results.csv
python3 seed_summary.py results/seed_study_results.csv
python3 seed_kkt.py seedpack inputs/KU 300
python3 propagation.py ../../standard_benchmark inputs/KU results/seed_study_results.csv.gz
```

`plan_gain.py ../../standard_benchmark` rebuilds `inputs/KU/` from the stored model, gain and terminal weight.

## 3. Closed loop (Table IV)

```sh
cd revision/julia/closed_loop                    # needs the plant copies made by run_all.sh
bash run_closed_loop.sh                          # Double IP
PLANTS=single bash run_closed_loop.sh            # Single IP
python3 ../../analysis/closed_loop_summary.py ../../output
```

## 4. Figs. 2 and 3

```sh
bash revision/julia/single_figure/run_single_figure.sh   # Fig. 2 (Single IP, observer budgets)
bash revision/julia/double_figure/run_double_figure.sh   # Fig. 3 (Double IP, dropout and combined)
```

Both scripts need CairoMakie and use the macOS Times New Roman font path (edit for other systems).
Each writes its PDF/PNG next to the script.

## Scope

The outward-rounded checks certify the stored finite-decimal nominal problems, not floating-point
network or solver evaluation or the nonlinear dynamics. Projections and primal-dual checks are numerical.
This archive corresponds to the manuscript submitted to IEEE TAC (October 2026).
