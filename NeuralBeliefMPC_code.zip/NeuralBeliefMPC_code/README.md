# Code for "Neural Belief Corrections for MPC: Plan-Consistent Scalar Budgets versus Myopic Directional Constraints"

T. Nuchkrua, X. Liu, and S. Boonto. Project page: https://thanana.github.io/NeuralBeliefMPC.html
Contact: Sudchai Boonto (sudchai.boo@kmutt.ac.th), Thanana Nuchkrua (thanana.nuch@yahoo.com).

Simulations, observers and MPC run in Julia 1.12.1. Post hoc analysis uses Python 3.12
(NumPy, SciPy, CVXPY with Clarabel). Tested on macOS (Apple silicon).

## Contents

| Folder | What it is |
|---|---|
| `standard_benchmark/single`, `standard_benchmark/double` | Pinned Julia environments (`Project.toml`, `Manifest.toml`), trained checkpoints, MPC data and certificates of the single and double inverted pendulum; `PROTOCOL.md` gives the full protocol |
| `revision/julia/` | Replay of 2 plants x 5 profiles x 5 seeds and frozen-context extraction (`run_all.sh`); closed-loop deployment of the postprocessors (`closed_loop/`); Fig. 3 (`pam_figure/`) |
| `revision/analysis/` | Pooled projection study, summaries, duality certificates and Proposition 3 constants (Python) |
| `revision/analysis/inputs/` | Packed frozen contexts of the 50 replays (`seedpack.tgz`) and predicted-input maps (`KU/`) |
| `revision/analysis/results/` | Every pooled context (`seed_study_results.csv.gz`) and every closed-loop run (`closed_loop_results.csv`) |
| `pam_surrogate/results_pam_v4/` | PAM traces used for Fig. 3 |
| `revision/video/` | Scripts that assemble Supplementary Video S1 from saved logs |

Raw per-tick records of all 600 pendulum and 120 PAM episodes (about 280 MB) are available from the authors on request.

## 1. Replay and frozen contexts (Sec. IV-D)

```sh
cd revision/julia
bash run_all.sh                                  # 50 episodes, about 1 min each
SEEDS=96301 PROFILES=combined bash run_all.sh    # quick check
```

The scripts work on a copy of `standard_benchmark/` and write to `revision/output/`.

## 2. Pooled study (Table III) and Proposition 3 constants

```sh
cd revision/analysis
tar xzf inputs/seedpack.tgz                      # or: python3 pack_seeds.py ../output seedpack
python3 seed_study.py seedpack inputs/KU results/seed_study_results.csv
python3 seed_summary.py results/seed_study_results.csv
python3 seed_kkt.py seedpack inputs/KU 300
python3 propagation.py ../../standard_benchmark inputs/KU results/seed_study_results.csv.gz
```

`plan_gain.py ../../standard_benchmark` rebuilds `inputs/KU/` from the stored model, gain and terminal weight.

## 3. Closed loop (Table IV)

```sh
cd revision/julia/closed_loop                    # needs the plant copies made by run_all.sh
bash run_closed_loop.sh                          # Double IP
PLANTS=single bash run_closed_loop.sh            # Single IP
python3 ../../analysis/closed_loop_summary.py ../../output
```

## 4. Fig. 3 (PAM)

```sh
bash revision/julia/pam_figure/run_pam_figure.sh   # needs CairoMakie; uses the macOS Times New Roman font path
```
