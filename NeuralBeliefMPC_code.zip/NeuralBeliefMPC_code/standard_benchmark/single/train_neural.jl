# Dimension-adapted training pipeline from supplied IP code.
include("mpc_core.jl")
include("neural_core.jl")
include("load_dataset.jl")
function column_stats(X)
    vec(mean(X;dims=2)),max.(vec(std(X;dims=2)),.1)
end
function gaussian_loss(mean,sd,target;mask=ones(size(target)))
    sum(mask .* (0.5 .* ((target-mean)./sd).^2 .+ log.(sd)))/sum(mask)
end
function train_flat(p,re,train_loss,valid_loss,nsamples;epochs=40,seed=1,name="model",batch=256)
    rng=MersenneTwister(seed);state=Flux.setup(Flux.Adam(.001),p)
    best=copy(p);bestloss=valid_loss(re(p));initial=bestloss;history=Any[]
    for epoch in 1:epochs
        order=randperm(rng,nsamples)
        for lo in 1:batch:nsamples
            ids=order[lo:min(lo+batch-1,nsamples)]
            g=Flux.gradient(q->train_loss(re(q),ids),p)[1]
            @assert all(isfinite,g)
            g.*=min(1.,10/max(norm(g),1e-12))
            Flux.update!(state,p,g);p.=clamp.(p,-PARAM_BOX,PARAM_BOX)
        end
        val=valid_loss(re(p));push!(history,[epoch,val])
        if val<bestloss;best=copy(p);bestloss=val;end
        epoch%5==0&&(println(name," epoch ",epoch," valid loss ",round(val,digits=5)," best ",round(bestloss,digits=5));flush(stdout))
    end
    println(name," initial validation ",initial," best ",bestloss);flush(stdout)
    best,history,initial,bestloss
end
function encoder_data(nn,episodes)
    Fs=Vector{Float64}[];Ms=Vector{Float64}[];targets=Vector{Float64}[];Ls=Matrix{Float64}[]
    for (index,ep) in enumerate(episodes)
        obs=NeuralObserver(nn,:frozen)
        for k in 1:size(ep.Z,2)
            c=correction_context(obs.nn,obs.mean,obs.cov,ep.Y[:,k],ep.mask[:,k],obs.previous_u)
            push!(Fs,c.features);push!(Ms,c.mean);push!(targets,ep.Z[:,k]);push!(Ls,inv(Matrix(cholesky(Symmetric(c.cov)).L)))
            # Encoder is fitted only after these frozen-neural Gaussian contexts are built.
            obs.mean=c.mean;obs.cov=c.cov;predict_neural!(obs,9.5ep.U[1,k])
        end
        index%8==0&&(println("Encoder contexts ",index," / ",length(episodes));flush(stdout))
    end
    (F=reduce(hcat,Fs),M=reduce(hcat,Ms),Y=reduce(hcat,targets),L=stack(Ls))
end
function encoder_loss(net,data,ids,m,s)
    mean,tau=neural_encoder(net,data.F[:,ids],data.M[:,ids],m,s)
    e=(data.Y[:,ids]-mean).*exp.(-tau/2)
    whitened=Flux.NNlib.batched_mul(data.L[:,:,ids],reshape(e,NZ,1,:))
    (sum(abs2,whitened)+sum(tau))/(2length(ids)*NZ)
end
function main_train()
    BLAS.set_num_threads(1)
    quick=get(ENV,"DIP_QUICK","0")=="1"
    train=load_dataset("training")
    valid=load_dataset("validation")
    Z=hcat([e.Z for e in train]...);ZN=hcat([e.ZN for e in train]...);U=hcat([e.U for e in train]...)
    Y=hcat([e.Y for e in train]...);mask=Float64.(hcat([e.mask for e in train]...))
    VZ=hcat([e.Z for e in valid]...);VZN=hcat([e.ZN for e in valid]...);VU=hcat([e.U for e in valid]...)
    VY=hcat([e.Y for e in valid]...);VM=Float64.(hcat([e.mask for e in valid]...))
    design=build_design(out=joinpath(@__DIR__,"design"))
    A=Matrix{Float64}(I,NZ,NZ);A[1:NX,1:NX]=Diagonal(1 ./ ZS[1:NX])*design.A*Diagonal(ZS[1:NX])
    B=zeros(NZ,1);B[1:NX,:]=Diagonal(1 ./ ZS[1:NX])*design.B*9.5
    C=zeros(NY,NZ);C[:,1:NX]=Diagonal(1 ./ YS)*OBS_MAP*Diagonal(ZS[1:NX]);C[2,NX+1]=1.
    fm,fs=column_stats(vcat(Z,U));hm,hs=column_stats(Z)
    theta,rt=flat_mlp(NZ+1,2NZ;seed=11);psi,rh=flat_mlp(NZ,2NY;hidden=16,seed=12);phi,rp=flat_mlp(NFEAT,2NZ;seed=13)
    tloss(net,ids)=gaussian_loss(neural_transition(net,Z[:,ids],U[:,ids],A,B,fm,fs)...,ZN[:,ids])
    tv(net)=gaussian_loss(neural_transition(net,VZ,VU,A,B,fm,fs)...,VZN)
    theta,ht,it,bt=train_flat(theta,rt,tloss,tv,size(Z,2);epochs=quick ? 5 : 50,seed=101,name="transition")
    mkpath(joinpath(@__DIR__,"checkpoints"));serialize(joinpath(@__DIR__,"checkpoints","transition.jls"),(theta,ht,it,bt))
    hloss(net,ids)=gaussian_loss(neural_observation(net,Z[:,ids],C,hm,hs)...,Y[:,ids];mask=mask[:,ids])
    hv(net)=gaussian_loss(neural_observation(net,VZ,C,hm,hs)...,VY;mask=VM)
    psi,hh,ih,bh=train_flat(psi,rh,hloss,hv,size(Z,2);epochs=quick ? 5 : 35,seed=102,name="observation")
    serialize(joinpath(@__DIR__,"checkpoints","observation.jls"),(psi,hh,ih,bh))
    initstats=(fmean=fm,fscale=fs,hmean=hm,hscale=hs,emean=zeros(NFEAT),escale=ones(NFEAT))
    nn=make_bundle(phi,theta,psi,initstats,A,B,C)
    td=encoder_data(nn,train);vd=encoder_data(nn,valid);em,es=column_stats(td.F)
    eloss(net,ids)=encoder_loss(net,td,ids,em,es)
    ev(net)=encoder_loss(net,vd,collect(1:size(vd.F,2)),em,es)
    phi,he,ie,be=train_flat(phi,rp,eloss,ev,size(td.F,2);epochs=quick ? 5 : 40,seed=103,name="encoder",batch=128)
    nn=make_bundle(phi,theta,psi,(fmean=fm,fscale=fs,hmean=hm,hscale=hs,emean=em,escale=es),A,B,C)
    out=joinpath(@__DIR__,"models");mkpath(out)
    for (name,array) in [("phi",phi),("theta",theta),("psi",psi),("fmean",fm),("fscale",fs),
       ("hmean",hm),("hscale",hs),("emean",em),("escale",es),("A8",A),("B8",B),("C8",C)]
        writedlm(joinpath(out,name*".csv"),array,',')
    end
    for (name,hist) in [("transition",ht),("observation",hh),("encoder",he)]
        open(joinpath(out,name*"_training.csv"),"w") do io
            println(io,"epoch,validation_loss");for row in hist;println(io,join(row,','));end
        end
    end
    open(joinpath(out,"training_report.txt"),"w") do io
        println(io,"Native Julia/Flux supervised Gaussian pretraining, not unsupervised SVI")
        println(io,"Training episodes=",length(train),"; validation episodes=",length(valid),"; quick=",quick)
        println(io,"Evaluation seeds 96301--96305 were not used for fitting or checkpoint choice")
        println(io,"Latent dimension 6: normalized physical 4, bias, pole-mass deviation")
        println(io,"Two ReLU hidden layers: transition/encoder width32; observation width16")
        println(io,"Parameter counts phi=",length(phi)," theta=",length(theta)," psi=",length(psi))
        println(io,"Validation loss initial -> best: transition ",it," -> ",bt,"; observation ",ih," -> ",bh,"; encoder ",ie," -> ",be)
        println(io,"Decoder fixed physical projection; mean/covariance networks physically anchored")
        println(io,"Weights projected into [-2,2]; input normalized using training statistics and clipped [-6,6]")
    end
    println("Saved trained neural weights and reports")
end
abspath(PROGRAM_FILE)==abspath(@__FILE__)&&main_train()
