const NP=1
const NY=NP+1
const NX=2NY
const NZ=NX+2
const NFEAT=2NZ+NZ*(NZ-1)÷2+2NY+1
const ZS=vcat(.75,fill(deg2rad(11.),NP),ones(NY),deg2rad(11.),1.)
const YS=vcat(.75,fill(deg2rad(11.),NP))
const ABS_MAP=Matrix{Float64}(I,NX,NX)
for j in 2:NY
 ABS_MAP[j,2:j].=1.; ABS_MAP[NY+j,NY+2:NY+j].=1.
end
const OBS_MAP=ABS_MAP[1:NY,:]
