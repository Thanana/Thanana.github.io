include("mpc_core.jl")
include("neural_core.jl")
using Serialization
function dataset(count,startseed,design)
 episodes=NamedTuple[]
 for ep in 1:count
  seed=startseed+ep;rng=MersenneTwister(seed);ratios=[.85+.3rand(rng),.85+.65rand(rng)]
  models=DPDynamics.load_model_ratio.(ratios);data=DPDynamics.MuJoCo.init_data.(models)
  x=vcat(.02+.02randn(rng),deg2rad(2.)+deg2rad(.5)*randn(rng),deg2rad(-1.).+deg2rad(.5).*randn(rng,NP-1),.01randn(rng),.02randn(rng,NP))
  phase=2pi*rand(rng);shift=.6+rand(rng);bias_on=.3+.7rand(rng);drop=.7+rand(rng);bmax=rand(rng)<.35 ? 0. : deg2rad(1+2rand(rng))*rand(rng,[-1,1])
  Z=zeros(NZ,300);ZN=zeros(NZ,300);U=zeros(1,300);Y=zeros(NY,300);mask=trues(NY,300)
  for k in 0:299
   time=k*.02;mode=time>=shift ? 2 : 1;b=bmax*clamp(time-bias_on,0.,1.);y=OBS_MAP*x;y[2]+=b;y.+=DPDynamics.SENSOR_STD.*randn(rng,NY)
   available=!(drop<=time<drop+.12||rand(rng)<.025);mask[2:NY,k+1].=available;y[2:NY].*=available
   ref=zeros(NX);ref[1]=.04sin(1.3time+phase);ref[NY+1]=.052cos(1.3time+phase)
   u=clamp(only(-design.K*(x-ref))+.4sin(7time+phase)+.1randn(rng),-9.5,9.5)
   next=DPDynamics.transition!(models[mode],data[mode],x,u);nt=time+.02
   Z[:,k+1]=vcat(x,b,ratios[mode]-1)./ZS;ZN[:,k+1]=vcat(next,bmax*clamp(nt-bias_on,0.,1.),ratios[nt>=shift ? 2 : 1]-1)./ZS;U[1,k+1]=u/9.5;Y[:,k+1]=y./YS;x=next
  end
  push!(episodes,(seed=seed,Z=Z,ZN=ZN,U=U,Y=Y,mask=mask));ep%8==0&&(println("Data ",ep,"/",count);flush(stdout))
 end
 episodes
end
BLAS.set_num_threads(1);design=build_design();mkpath(joinpath(@__DIR__,"data"))
serialize(joinpath(@__DIR__,"data/training.jls"),dataset(64,6000,design))
serialize(joinpath(@__DIR__,"data/validation.jls"),dataset(16,8000,design))
println("Training/validation data complete")
