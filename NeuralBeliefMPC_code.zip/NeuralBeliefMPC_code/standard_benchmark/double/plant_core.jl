# Coded by Thanana of the Control Lab.
using MuJoCo,LinearAlgebra,Random,Printf
include("config.jl")
const DT=.02
const SUBSTEPS=2
const LIMITS=(position=.8,angle=deg2rad(12.),force=10.)
const SENSOR_STD=vcat(.002,fill(deg2rad(.2),NP))
function model_xml(;ratio=1.)
 xml=read(joinpath(@__DIR__,"benchmark.xml"),String)
 replace(xml,"<geom name=\"pole_$(NP)\" />"=>"<geom name=\"pole_$(NP)\" mass=\"$(.1ratio)\" />")
end
function load_model_ratio(ratio=1.)
 folder=joinpath(@__DIR__,"physics_models");mkpath(folder)
 path=joinpath(folder,"ratio_$(ratio).xml");write(path,model_xml(;ratio))
 # Preserve upstream visual assets; paths stay relative to the model file.
 for name in ["skybox.xml","materials.xml","visual.xml"]
  mkpath(joinpath(folder,"common"));cp(joinpath(@__DIR__,"common",name),joinpath(folder,"common",name);force=true)
 end
 MuJoCo.load_model(path)
end
function transition!(model,data,x,u;audit=nothing)
 MuJoCo.reset!(model,data);data.qpos.=x[1:NY];data.qvel.=x[NY+1:NX];data.ctrl[1]=u/10
 MuJoCo.forward!(model,data)
 for _ in 1:SUBSTEPS
  MuJoCo.step!(model,data)
  if audit!==nothing
   pos=vec(collect(data.qpos));absangles=cumsum(pos[2:NY]);audit[1]=max(audit[1],abs(pos[1]));audit[2]=max(audit[2],maximum(abs,absangles));audit[3]=max(audit[3],Float64(abs(pos[1])>.8||maximum(abs,absangles)>deg2rad(12.)))
  end
  any(data.warning[j].number>0 for j in 5:8)&&error("MuJoCo numerical warning; episode is incomplete")
 end
 vcat(vec(collect(data.qpos)),vec(collect(data.qvel)))
end
function linearize(model,data,x,u)
 h=1e-5;A=zeros(NX,NX)
 for j in 1:NX
  dx=zeros(NX);dx[j]=h;A[:,j]=(transition!(model,data,x+dx,u)-transition!(model,data,x-dx,u))/(2h)
 end
 B=reshape((transition!(model,data,x,u+h)-transition!(model,data,x,u-h))/(2h),NX,1);A,B
end
function lqr_gain(A,B)
 Q=ABS_MAP'*Diagonal(vcat(10.,fill(120.,NP),1.,fill(5.,NP)))*ABS_MAP;R=reshape([.15],1,1);P=copy(Q)
 for _ in 1:50000
  pn=Matrix(Symmetric(Q+A'*P*A-A'*P*B*((R+B'*P*B)\(B'*P*A))))
  if norm(pn-P)/max(norm(P),1.)<1e-11
   K=(R+B'*pn*B)\(B'*pn*A);@assert maximum(abs,eigvals(A-B*K))<1;return K
  end
  P=pn
 end
 error("LQR iteration did not converge")
end
