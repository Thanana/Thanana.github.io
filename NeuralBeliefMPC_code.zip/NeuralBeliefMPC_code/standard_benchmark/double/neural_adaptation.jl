# Coded by Thanana of the Control Lab.

const GATE_BUDGET=Ref(.002)
# Adapted from supplied neural_adaptation.jl; original CF guard constants retained.
include("neural_core.jl")
function replay_batch(items)
    F=reduce(hcat,[x.features for x in items]);M=reduce(hcat,[x.mean for x in items])
    U=reshape([x.u/9.5 for x in items],1,:);Y=reduce(hcat,[x.y for x in items])
    W=stack([begin E=eigen(Symmetric(x.precision));Diagonal(sqrt.(max.(E.values,0.)))*E.vectors' end for x in items])
    (F=F,M=M,U=U,Y=Y,W=W,Cdiag=reduce(hcat,[x.cdiag for x in items]),radii=reshape([x.radius for x in items],1,:))
end
function cached_loss(nn,v,b)
    n=length(nn.phi);phi=v[1:n];theta=v[n+1:end]
    raw,tau=neural_encoder(nn.re_phi(phi),b.F,b.M,nn.emean,nn.escale)
    if all(isinf,b.radii)
        z=raw
    else
        rho=sqrt.(sum((raw[1:NX,:]-b.M[1:NX,:]).^2;dims=1)+sum((exp.(tau[1:NX,:]/2).-1).^2 .* b.Cdiag;dims=1).+1e-24)
        lambda=min.(1.,b.radii./rho)
        z=b.M+lambda.*(raw-b.M)
    end
    zp,_=neural_transition(nn.re_theta(theta),z,b.U,nn.A,nn.B,nn.fmean,nn.fscale)
    yp,_=neural_observation(nn.re_psi(nn.psi),zp,nn.C,nn.hmean,nn.hscale)
    e=Flux.NNlib.batched_mul(b.W,reshape(yp-b.Y,NY,1,:))
    .5sum(abs2,e)/size(b.Y,2)+REGULARIZER*(sum(abs2,phi-nn.anchor_phi)+sum(abs2,theta-nn.anchor_theta))
end
function project_candidate(v,anchor)
    d=v-anchor;r=norm(d)
    clamp.(anchor+d*min(1.,ANCHOR_RADIUS/max(r,1e-30)),-PARAM_BOX,PARAM_BOX)
end
function adapt_neural!(obs,ctx)
    nn=obs.nn;n=length(nn.phi);old=vcat(nn.phi,nn.theta)
    zero_diag=(attempted=false,accepted=false,trials=0,phi_step=0.,theta_step=0.,joint_step=0.,CFI=0.,joint_index=0.,coupling=0.,loss_before=NaN,loss_after=NaN,gradient=0.,budget_rejections=0,adapt_ms=0.)
    obs.policy in (:neural_frozen,:neural_gaussian)&&return zero_diag
    (obs.tick%ONLINE_INTERVAL!=0||length(obs.replay)<4)&&return zero_diag
    tic=time_ns();batch=replay_batch(obs.replay);before=cached_loss(nn,old,batch)
    g=Flux.gradient(v->cached_loss(nn,v,batch),old)[1]
    obs.policy==:neural_transition&&(g[1:n].=0)
    obs.policy in (:neural_encoder,:neural_encoder_no_trust)&&(g[n+1:end].=0)
    gn=norm(g);g.*=min(1.,GRAD_LIMIT/max(gn,1e-30))
    delta=-ONLINE_ETA/(1+ctx.surprise)*g
    guarded=obs.policy!=:neural_ungated
    guarded&&(delta.*=min(1.,EPS_JOINT/max(norm(delta),1e-30)))
    anchor=vcat(nn.anchor_phi,nn.anchor_theta);m0,P0=encoded_belief(nn,ctx)
    accepted=false;trials=0;blocks=0;after=before;coupling=0.;candidate=old
    for j in 0:7
        trials+=1;v=project_candidate(old+2.0^(-j)*delta,anchor)
        m1,P1=encoded_belief(nn,ctx;phi=v[1:n]);rho=physical_coupling(m0,P0,m1,P1)
        if guarded&&rho>GATE_BUDGET[]+1e-12
            blocks+=1;continue
        end
        if obs.policy==:neural_joint_predictive
            # Guard the next predicted belief, including transition parameters.
            blocked=false
            for u in (-9.5,obs.previous_u,9.5)
                a,sa,Ja=transition_stats(nn,m0,u)
                b,sb,Jb=transition_stats(nn,m1,u;theta=v[n+1:end])
                Pa=covariance_proxy_projection(Ja*P0*Ja'+Diagonal(sa.^2))
                Pb=covariance_proxy_projection(Jb*P1*Jb'+Diagonal(sb.^2))
                anchor_mean,_,_=transition_stats(nn,m1,u;theta=nn.anchor_theta)
                if physical_coupling(a,Pa,b,Pb)>GATE_BUDGET[] || norm(b[1:NX]-anchor_mean[1:NX])>.002
                    blocked=true;break
                end
            end
            if blocked
                blocks+=1;continue
            end
        end
        val=cached_loss(nn,v,batch)
        if isfinite(val)&&val<=before-1e-4sum(abs2,v-old)+1e-12
            accepted=true;candidate=v;after=val;coupling=rho;break
        end
    end
    step=candidate-old;ps=norm(step[1:n]);ts=norm(step[n+1:end]);js=norm(step)
    if accepted
        nn.phi=copy(candidate[1:n]);nn.theta=copy(candidate[n+1:end])
    end
    guarded&&(@assert js<=EPS_JOINT+1e-10&&ps<=EPS_PHI+1e-10&&coupling<=GATE_BUDGET[]+1e-10)
    @assert norm(vcat(nn.phi,nn.theta)-anchor)<=ANCHOR_RADIUS+1e-10
    @assert maximum(abs,vcat(nn.phi,nn.theta))<=PARAM_BOX+1e-10
    (attempted=true,accepted=accepted,trials=trials,phi_step=ps,theta_step=ts,joint_step=js,
      CFI=ps/EPS_PHI,joint_index=js/EPS_JOINT,coupling=coupling,loss_before=before,
      loss_after=after,gradient=gn,budget_rejections=blocks,adapt_ms=(time_ns()-tic)/1e6)
end
function correct_neural!(obs,y,mask)
    obs.tick+=1;nn=obs.nn;yn=y./YS
    ctx=correction_context(nn,obs.mean,obs.cov,yn,mask,obs.previous_u)
    obs.policy in (:neural_no_trust,:neural_encoder_no_trust)&&(ctx=merge(ctx,(trust_radius=Inf,)))
    obs.policy==:neural_gaussian&&(ctx=merge(ctx,(trust_radius=0.,)))
    if obs.previous_context!==nothing
        old=obs.previous_context
        push!(obs.replay,(features=copy(old.features),mean=copy(old.mean),cdiag=copy(diag(old.cov)[1:NX]),radius=old.trust_radius,u=obs.previous_u,y=copy(yn),precision=copy(ctx.precision)))
        length(obs.replay)>REPLAY_SIZE&&popfirst!(obs.replay)
    end
    oldm,oldP=encoded_belief(nn,ctx);d=adapt_neural!(obs,ctx)
    obs.mean,obs.cov=encoded_belief(nn,ctx);obs.previous_context=ctx
    x,P=decode(obs.mean,obs.cov)
    reference_coupling=physical_coupling(ctx.mean,ctx.cov,obs.mean,obs.cov)
    isfinite(ctx.trust_radius)&&(@assert reference_coupling<=ctx.trust_radius+1e-10)
    (mean=x,cov=P,bias=ZS[NX+1]*obs.mean[NX+1],mass=1+obs.mean[NX+2],surprise=ctx.surprise,nll=ctx.nll,
      reference_coupling=reference_coupling,encoder_radius=ctx.trust_radius,diagnostics=d,reference_mean=ZS[1:NX].*ctx.mean[1:NX],oldmean=oldm,oldcov=oldP,newmean=copy(obs.mean),newcov=copy(obs.cov))
end
