# Coded by Thanana of the Control Lab.
const MASS_GRID=[.7,1.,1.5,2.]
const ANCHOR_CONFIG=Ref((bias_sd=deg2rad(.03),residual_weight=.02,radius=2e-5))
