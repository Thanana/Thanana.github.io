# Coded by Thanana of the Control Lab.

include("mpc_core.jl")
BLAS.set_num_threads(1)
m=DPDynamics.load_model_ratio();s=DPDynamics.MuJoCo.init_data(m)
@assert maximum(abs,DPDynamics.transition!(m,s,zeros(NX),0.))<1e-12
@assert abs(sum(collect(m.body_mass))-1-.1NP)<1e-12
open(joinpath(@__DIR__,"compiled_parameters.txt"),"w") do io
 println(io,"Source: dm_control commit 773d5b5d94d8f58943cf56a66b9b9755818fe5b4; cartpole model with ",NP," chained poles")
 for field in [:body_mass,:body_inertia,:body_ipos,:dof_damping,:actuator_gear,:actuator_ctrlrange]
  println(io,field," = ",collect(getproperty(m,field)))
 end
 println(io,"Control interval 0.02 s, two upstream 0.01 s RK4 steps; force u maps to action u/10")
 println(io,"Task additions: noisy partial sensing, bias/dropout/mass faults, constrained MPC; not original suite reward protocol")
end
println("Compiled physical parameters and upright equilibrium checked")
