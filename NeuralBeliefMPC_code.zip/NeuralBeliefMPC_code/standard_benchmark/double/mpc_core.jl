# Dimension-adapted nominal MPC from supplied mpc_core.jl.
# Stage 2: nominal hard-constrained linear MPC, not robust/chance-certified BMPC.
# Coded by Thanana of the Control Lab.

using JuMP, HiGHS, OSQP, LinearAlgebra, SparseArrays, DelimitedFiles, Statistics, Random, Test
include("config.jl")
module DPDynamics
    include("plant_core.jl")
    const OBS_R=Matrix(Diagonal(SENSOR_STD.^2))
end
const POS_BOUND = 0.75
const ANG_BOUND = deg2rad(11.0)
const INPUT_BOUND = 9.5
const ACCEPT_TOL = 2e-5
const STAGE_Q = ABS_MAP'*Diagonal(vcat(10.,fill(100.,NP),1.,fill(5.,NP)))*ABS_MAP
const STAGE_R = 0.2

function terminal_cost(A,B,K)
    F=A-B*K; L=STAGE_Q+STAGE_R*K'*K; P=copy(L)
    for _ in 1:20000
        pn=Matrix(Symmetric(L+F'*P*F))
        if norm(pn-P)<=1e-12*max(norm(P),1)
            return pn
        end
        P=pn
    end
    error("Terminal Lyapunov iteration did not converge")
end
function support_lp(H,c)
    n=size(H,2)
    lp=JuMP.Model(HiGHS.Optimizer);set_silent(lp)
    set_optimizer_attribute(lp,"primal_feasibility_tolerance",1e-9)
    set_optimizer_attribute(lp,"dual_feasibility_tolerance",1e-9)
    @variable(lp,z[1:n])
    @constraint(lp,[j=1:size(H,1)],sum(H[j,i]*z[i] for i in 1:n)<=1.)
    @objective(lp,Max,sum(c[i]*z[i] for i in 1:n))
    optimize!(lp);status=termination_status(lp)
    status==JuMP.MOI.OPTIMAL && return objective_value(lp)
    status in (JuMP.MOI.DUAL_INFEASIBLE,JuMP.MOI.INFEASIBLE_OR_UNBOUNDED) && return Inf
    error("Terminal support LP did not solve: $status")
end
function terminal_set(A,B,K;max_steps=250)
    F=A-B*K
    C=vcat(Diagonal(vcat(1/POS_BOUND,fill(1/ANG_BOUND,NP)))*OBS_MAP,K/INPUT_BOUND,.5ABS_MAP[NY+1:NX,:])
    H0=vcat(C,-C);H=copy(H0);power=Matrix{Float64}(I,NX,NX)
    stopped=false;stopping_step=0
    for j in 1:max_steps
        power=power*F;next=H0*power;added=0
        for i in axes(next,1)
            row=vec(next[i,:])
            if support_lp(H,row)>1+1e-6
                H=vcat(H,reshape(row,1,NX));added+=1
            end
        end
        if added==0
            stopped=true;stopping_step=j;break
        end
    end
    @assert stopped "No finite terminal-set certificate; increase limit or revise model"
    # Independent support audit of every retained facet, rather than sampled states.
    values=[support_lp(H,vec((H*F)[i,:])) for i in axes(H,1)]
    @assert maximum(values)<=1+3e-6
    H,stopping_step,maximum(values)
end
mutable struct LinearMPC
    A::Matrix{Float64}
    B::Matrix{Float64}
    K::Matrix{Float64}
    P::Matrix{Float64}
    H::Matrix{Float64}
    N::Int
    model::OSQP.Model
    base_lower::Vector{Float64}
    base_upper::Vector{Float64}
    state_offset::Matrix{Float64}
    q_offset::Matrix{Float64}
    Sx::Matrix{Float64}
    Tx::Matrix{Float64}
    Su::Matrix{Float64}
    Tu::Matrix{Float64}
    lastU::Union{Nothing,Vector{Float64}}
    lastX::Union{Nothing,Matrix{Float64}}
end
function LinearMPC(A,B,K,P,H;N=50)
    # Exact pre-stabilized condensing: u_j=-K*x_j+v_j.
    # F is stable; eliminate equality constraints without changing the MPC problem.
    nx=NX*(N+1);F=A-B*K
    Sx=zeros(nx,NX);Tx=zeros(nx,N);Sx[1:NX,:]=Matrix{Float64}(I,NX,NX)
    for j in 1:N
        prev=NX*(j-1).+(1:NX);nxt=NX*j.+(1:NX)
        Sx[nxt,:]=F*Sx[prev,:];Tx[nxt,:]=F*Tx[prev,:];Tx[nxt,j]=B[:,1]
    end
    Su=zeros(N,NX);Tu=Matrix{Float64}(I,N,N)
    for j in 1:N
        ix=NX*(j-1).+(1:NX)
        Su[j,:]=vec(-K*Sx[ix,:]);Tu[j,:]-=vec(K*Tx[ix,:])
    end
    W=zeros(nx,nx)
    for j in 1:N;ix=NX*(j-1).+(1:NX);W[ix,ix]=STAGE_Q;end
    W[NX*N.+(1:NX),NX*N.+(1:NX)]=P
    G=Matrix(Symmetric(2*(Tx'*W*Tx+STAGE_R*Tu'*Tu)))
    qoffset=2*(Tx'*W*Sx+STAGE_R*Tu'*Su)
    # Constraints M*v + C*x0 in [lo,hi]. Include current-state bounds too.
    select=zeros(NY*(N+1),nx)
    for j in 1:N+1
        columns=NX*(j-1).+(1:NX); rows=NY*(j-1).+(1:NY)
        select[rows,columns]=OBS_MAP
    end
    terminal=NX*N.+(1:NX)
    M=vcat(select*Tx,Tu,H*Tx[terminal,:])
    C=vcat(select*Sx,Su,H*Sx[terminal,:])
    limits=repeat(vcat(POS_BOUND,fill(ANG_BOUND,NP)),N+1)
    lo=vcat(-limits,fill(-INPUT_BOUND,N),fill(-Inf,size(H,1)))
    hi=vcat(limits,fill(INPUT_BOUND,N),ones(size(H,1)))
    model=OSQP.Model()
    OSQP.setup!(model;P=sparse(triu(G)),q=zeros(N),A=sparse(M),l=lo,u=hi,
                verbose=false,eps_abs=1e-7,eps_rel=1e-7,max_iter=20000,polish=true)
    LinearMPC(A,B,K,P,H,N,model,lo,hi,C,qoffset,Sx,Tx,Su,Tu,nothing,nothing)
end
function rollout(c,x,U)
    X=zeros(NX,c.N+1);X[:,1]=x
    for j in 1:c.N;X[:,j+1]=c.A*X[:,j]+c.B[:,1]*U[j];end
    X
end
function plan_check(c,X,U,x0)
    defects=[norm(X[:,j+1]-c.A*X[:,j]-c.B[:,1]*U[j],Inf) for j in 1:c.N]
    dyn=max(norm(X[:,1]-x0,Inf),maximum(defects))
    pos=max(maximum(abs.(X[1,:]))-POS_BOUND,0.)
    ang=max(maximum(abs.(OBS_MAP[2:NY,:]*X))-ANG_BOUND,0.)
    force=max(maximum(abs.(U))-INPUT_BOUND,0.)
    terminal=max(maximum(c.H*X[:,end])-1,0.)
    residual=max(dyn,pos,ang,force,terminal)
    (valid=all(isfinite,X)&&all(isfinite,U)&&residual<=ACCEPT_TOL,
     residual=residual,terminal_level=maximum(c.H*X[:,end]))
end
function shifted_candidate(c,x)
    c.lastU===nothing && return (exists=false,valid=false,U=Float64[],X=zeros(NX,0),residual=NaN)
    U=vcat(c.lastU[2:end],clamp(only(-c.K*c.lastX[:,end]),-INPUT_BOUND,INPUT_BOUND))
    X=rollout(c,x,U);check=plan_check(c,X,U,x)
    (exists=true,valid=check.valid,U=U,X=X,residual=check.residual)
end
function solve_mpc!(c,x)
    shift=shifted_candidate(c,x)
    tic=time_ns()
    offset=c.state_offset*x
    OSQP.update!(c.model;q=c.q_offset*x,l=c.base_lower-offset,u=c.base_upper-offset)
    if shift.exists
        # Recover the condensed v from a shifted physical-input plan.
        V=shift.U+[only(c.K*shift.X[:,j]) for j in 1:c.N]
        OSQP.warm_start!(c.model;x=V)
    end
    result=OSQP.solve!(c.model);solver_ms=(time_ns()-tic)/1e6
    status=result.info.status==:Solved ? "OPTIMAL" : uppercase(string(result.info.status))
    accepted=false;residual=NaN;terminal=NaN;cost=NaN
    if result.info.status==:Solved
        V=result.x
        X=reshape(c.Sx*x+c.Tx*V,NX,c.N+1);U=c.Su*x+c.Tu*V
        check=plan_check(c,X,U,x);residual=check.residual
        if check.valid
            c.lastX=X;c.lastU=U;accepted=true;terminal=check.terminal_level
            cost=sum(dot(X[:,j],STAGE_Q*X[:,j])+STAGE_R*U[j]^2 for j in 1:c.N)+dot(X[:,end],c.P*X[:,end])
        end
    end
    source="mpc"
    if !accepted
        if shift.valid
            c.lastX=shift.X;c.lastU=shift.U;source="shifted_nominal"
            residual=shift.residual;terminal=maximum(c.H*shift.X[:,end])
        else
            # Explicitly uncertified recovery. It must never be counted as feasible MPC.
            c.lastX=nothing;c.lastU=nothing;source="uncertified_lqr"
        end
    end
    u=source=="uncertified_lqr" ? clamp(only(-c.K*x),-INPUT_BOUND,INPUT_BOUND) : c.lastU[1]
    (u=u,qp_accepted=accepted,status=string(status),source=source,
     shift_exists=shift.exists,shift_feasible=shift.valid,shift_residual=shift.residual,
     plan_residual=residual,terminal_level=terminal,cost=cost,solver_ms=solver_ms)
end
function build_design(;out=joinpath(@__DIR__,"results_mpc"))
    m=DPDynamics.MuJoCo.load_model(joinpath(@__DIR__,"benchmark.xml"))
    A,B=DPDynamics.linearize(m,DPDynamics.MuJoCo.init_data(m),zeros(NX),0.)
    K=DPDynamics.lqr_gain(A,B)
    P=terminal_cost(A,B,K);H,j,support=terminal_set(A,B,K)
    F=A-B*K;res=norm(P-F'*P*F-STAGE_Q-STAGE_R*K'*K,Inf)
    @assert eigmin(Symmetric(P))>0
    @assert res<1e-6
    mkpath(out)
    for (name,value) in [("A",A),("B",B),("K",K),("P",P),("H_terminal",H)]
        writedlm(joinpath(out,name*".csv"),value,',')
    end
    open(joinpath(out,"nominal_certificate.txt"),"w") do io
        println(io,"Certificate scope: deterministic nominal linear 20 ms model only")
        println(io,"No robustness/chance coverage/nonlinear-plant certification is claimed.")
        println(io,"Terminal facets = ",size(H,1),"; stopping power = ",j)
        println(io,"Maximum LP facet support under A-BK = ",support)
        println(io,"Closed-loop spectral radius = ",maximum(abs.(eigvals(F))))
        println(io,"Terminal decrease matrix residual (Inf norm) = ",res)
        println(io,"Planning bounds: p=",POS_BOUND," m, angle=",ANG_BOUND," rad, force=",INPUT_BOUND," N")
        println(io,"Physical evaluation bounds: 0.8 m, 12 degrees, 10 N")
        println(io,"Controller: nominal certainty-equivalent linear MPC, N=50, Q on position/absolute pole angles/velocities; HiGHS terminal support tolerance 3e-6, R=0.2")
    end
    (A=A,B=B,K=K,P=P,H=H)
end
