# Interacting multiple-model physics reference, moment-matched to the configured Gaussian belief.
# A fixed prior model bank represents uncertain mass; likelihoods select weights.
# No ground-truth mass, state or intervention schedule is supplied to this observer.
# Coded by Thanana of the Control Lab.

mutable struct IMMAnchorObserver
    base::NeuralObserver
    models
    data
    means::Vector{Vector{Float64}}
    covs::Vector{Matrix{Float64}}
    weights::Vector{Float64}
    angles_available::Bool
    learned::Bool
    ratios::Vector{Float64}
    biasaware::Bool
end
function IMMAnchorObserver(bundle;learned=true,ratios=MASS_GRID,biasaware=true)
    base=NeuralObserver(bundle,:neural_encoder)
    means=[vcat(base.mean[1:NX+1],r-1) for r in ratios]
    covs=[copy(base.cov) for _ in ratios]
    for P in covs;P[NZ,:].=0.;P[:,NZ].=0.;P[NZ,NZ]=COV_FLOOR;end
    models=DPDynamics.load_model_ratio.(ratios)
    IMMAnchorObserver(base,models,DPDynamics.MuJoCo.init_data.(models),means,covs,length(ratios)==4 ? [.05,.85,.08,.02] : ones(length(ratios))/length(ratios),true,learned,ratios,biasaware)
end
function mixture_moments(obs)
    m=sum(w*z for (w,z) in zip(obs.weights,obs.means))
    P=sum(w*(C+(z-m)*(z-m)') for (w,z,C) in zip(obs.weights,obs.means,obs.covs))
    m,covariance_proxy_projection(P)
end
function imm_transition(obs,i,z,u)
    x=DPDynamics.transition!(obs.models[i],obs.data[i],z[1:NX].*ZS[1:NX],u)
    m=vcat(x./ZS[1:NX],z[NX+1],obs.ratios[i]-1)
    beta=obs.learned && obs.angles_available ? ANCHOR_CONFIG[].residual_weight : 0.
    if beta>0
        learned,_,_=transition_stats(obs.base.nn,z,u)
        nominal=obs.base.nn.A*z+obs.base.nn.B[:,1]*(u/9.5)
        m[1:NX].+=beta.*(learned[1:NX]-nominal[1:NX])
    end
    m
end
function predict_neural!(obs::IMMAnchorObserver,u)
    n=length(obs.ratios)
    T=.99Matrix{Float64}(I,n,n)+.01ones(n,n)/n
    prior=T*obs.weights
    oldm=deepcopy(obs.means);oldP=deepcopy(obs.covs)
    for i in 1:n
        mixing=T[i,:].*obs.weights./prior[i]
        z=sum(mixing[j]*oldm[j] for j in 1:n)
        P=sum(mixing[j]*(oldP[j]+(oldm[j]-z)*(oldm[j]-z)') for j in 1:n)
        z[NZ]=obs.ratios[i]-1;P[NZ,:].=0.;P[:,NZ].=0.;P[NZ,NZ]=COV_FLOOR
        m=imm_transition(obs,i,z,u);J=zeros(NZ,NZ)
        for j in 1:NX+1
            dz=zeros(NZ);dz[j]=1e-4
            J[:,j]=(imm_transition(obs,i,z+dz,u)-imm_transition(obs,i,z-dz,u))/(2e-4)
        end
        sd=vcat(vcat(fill(1e-5,NY),.0005,fill(.002,NP)),obs.angles_available && obs.biasaware ? ANCHOR_CONFIG[].bias_sd/ZS[NX+1] : 0.,sqrt(COV_FLOOR))
        obs.means[i]=m;obs.covs[i]=covariance_proxy_projection(J*P*J'+Diagonal(sd.^2))
    end
    obs.weights=prior;obs.base.mean,obs.base.cov=mixture_moments(obs);obs.base.previous_u=u
end
function correct_neural!(obs::IMMAnchorObserver,y,mask)
    base=obs.base;base.tick+=1;nn=base.nn;yn=y./YS
    prior_m=copy(base.mean);prior_P=copy(base.cov)
    H=zeros(NY,NZ);H[:,1:NX]=Diagonal(1 ./ YS)*OBS_MAP*Diagonal(ZS[1:NX]);H[2,NX+1]=1
    ids=findall(mask);h=H[ids,:];R=Matrix(Diagonal(OBS_STD[ids].^2))
    logw=Float64[]
    for i in eachindex(obs.weights)
        z=obs.means[i];P=obs.covs[i];e=yn[ids]-h*z
        S=h*P*h'+R
        push!(logw,log(max(obs.weights[i],1e-300))-.5*(dot(e,S\e)+logdet(S)))
        K=(S\(h*P))';!all(mask)&&(K.=0.);!obs.biasaware&&(K[NX+1,:].=0.)
        D=Matrix{Float64}(I,NZ,NZ)-K*h
        obs.means[i]=z+K*e
        obs.covs[i]=covariance_proxy_projection(D*P*D'+K*R*K')
    end
    w=exp.(logw.-maximum(logw));obs.weights=w/sum(w)
    m,P=mixture_moments(obs)
    residual=yn-H*prior_m;S=h*prior_P*h'+R
    precision=zeros(NY,NY);precision[ids,ids]=inv(S)
    surprise=.5dot(residual[ids],S\residual[ids])
    radius=obs.learned && all(mask) ? ANCHOR_CONFIG[].radius : 0.
    ctx=(features=feature_vector(prior_m,prior_P,residual,mask,base.previous_u),mean=m,cov=P,
        precision=precision,surprise=surprise,nll=surprise,trust_radius=radius,mask=copy(mask))
    if !all(mask)
        empty!(base.replay);base.previous_context=nothing
    elseif base.previous_context!==nothing
        old=base.previous_context
        push!(base.replay,(features=copy(old.features),mean=copy(old.mean),cdiag=copy(diag(old.cov)[1:NX]),radius=old.trust_radius,u=base.previous_u,y=copy(yn),precision=copy(precision)))
        length(base.replay)>REPLAY_SIZE&&popfirst!(base.replay)
    end
    d=adapt_neural!(base,ctx);newm,newP=encoded_belief(nn,ctx)
    # Apply the projected neural correction to each component while keeping its
    # fixed mass hypothesis; this preserves the physical mixture mean/covariance.
    delta=newm-m;scale=sqrt.(diag(newP)./diag(P));scale[NZ]=1.;D=Diagonal(scale)
    for i in eachindex(obs.weights)
        obs.means[i][1:NX+1]=newm[1:NX+1]+scale[1:NX+1].*(obs.means[i][1:NX+1]-m[1:NX+1])
        obs.covs[i]=covariance_proxy_projection(D*obs.covs[i]*D)
    end
    base.mean,base.cov=mixture_moments(obs)
    base.previous_context=all(mask) ? ctx : nothing;obs.angles_available=all(mask)
    rho=physical_coupling(m,P,base.mean,base.cov)
    @assert rho<=radius+1e-8
    x,Px=decode(base.mean,base.cov)
    (mean=x,cov=Px,reference_coupling=rho,encoder_radius=ctx.trust_radius,diagnostics=d,reference_mean=ZS[1:NX].*m[1:NX])
end
