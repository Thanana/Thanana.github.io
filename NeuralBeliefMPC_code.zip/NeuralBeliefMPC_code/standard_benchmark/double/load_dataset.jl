# Coded by Thanana of the Control Lab.

using Serialization
load_dataset(name)=deserialize(joinpath(@__DIR__,"data",name*".jls"))
