# Adapted from supplied ip_neural_stage5/neural_core.jl for the configured physical dimension.
# Coded by Thanana of the Control Lab.

using Flux, Serialization, LinearAlgebra, Statistics, Random, DelimitedFiles
const MEAN_F=vcat(.02,fill(.04,NP),.1,fill(.2,NP),.02,.03)
const STD_F_FLOOR=vcat(fill(1e-5,NY),fill(.0003,NY),.0009,.0005)
const STD_F_SPAN=vcat(.0005,fill(.002,NP),.03,fill(.05,NP),.008,.05)
const MEAN_H=vcat(.01,fill(.02,NP))
const OBS_STD=DPDynamics.SENSOR_STD./YS
const STD_H_FLOOR=.1OBS_STD
const STD_H_SPAN=2OBS_STD
const MEAN_E=vcat(.02,fill(.03,NP),.05,fill(.1,NP),.08,.15)
const PARAM_BOX=2.
const ANCHOR_RADIUS=.25
const EPS_PHI=.002
const EPS_JOINT=.002
const EPS_BELIEF=.002
const ONLINE_ETA=.02
const GRAD_LIMIT=5.
const ONLINE_INTERVAL=10
const REPLAY_SIZE=16
const REGULARIZER=.001
const COV_FLOOR=1e-10
const COV_CAP=4.
const ENCODER_TRUST_RADIUS=Ref(isfile(joinpath(@__DIR__,"models","encoder_radius.csv")) ? Float64(readdlm(joinpath(@__DIR__,"models","encoder_radius.csv"),',')[1]) : Inf)
sigmoid_safe(x)=Flux.sigmoid.(x)
function mlp(din,dout;hidden=32,seed=1)
    rng=MersenneTwister(seed)
    init(dout,din)=sqrt(2/(din+dout))*randn(rng,dout,din)
    net=Chain(Dense(init(hidden,din),zeros(hidden),relu),
              Dense(init(hidden,hidden),zeros(hidden),relu),
              Dense(.01init(dout,hidden),zeros(dout)))
    net
end
function flat_mlp(din,dout;hidden=32,seed=1)
    p,re=Flux.destructure(mlp(din,dout;hidden=hidden,seed=seed))
    Vector{Float64}(p),re
end
normalized(X,m,s)=clamp.((X.-m)./s,-6.,6.)
function neural_transition(net,Z,U,A,B,m,s)
    out=net(normalized(vcat(Z,U),m,s))
    mean=A*Z+B*U+MEAN_F.*tanh.(out[1:NZ,:])
    sd=STD_F_FLOOR.+STD_F_SPAN.*sigmoid_safe(out[NZ+1:2NZ,:])
    mean,sd
end
function neural_observation(net,Z,C,m,s)
    out=net(normalized(Z,m,s))
    mean=C*Z+MEAN_H.*tanh.(out[1:NY,:])
    sd=STD_H_FLOOR.+STD_H_SPAN.*sigmoid_safe(out[NY+1:2NY,:])
    mean,sd
end
function neural_encoder(net,F,M,m,s)
    out=net(normalized(F,m,s))
    mean=M+MEAN_E.*tanh.(out[1:NZ,:])
    tau=2tanh.(out[NZ+1:2NZ,:])
    mean,tau
end
# Analytic input Jacobian of two-hidden-layer ReLU MLP; used by Gaussian moment filtering.
function raw_with_jacobian(net,x)
    l1,l2,l3=net.layers
    a=l1.weight*x+l1.bias;h=relu.(a)
    b=l2.weight*h+l2.bias;k=relu.(b)
    out=l3.weight*k+l3.bias
    J=l3.weight*Diagonal(Float64.(b.>0))*l2.weight*Diagonal(Float64.(a.>0))*l1.weight
    out,J
end
mutable struct NeuralSSM
    phi::Vector{Float64}
    theta::Vector{Float64}
    psi::Vector{Float64}
    re_phi
    re_theta
    re_psi
    fmean::Vector{Float64}
    fscale::Vector{Float64}
    hmean::Vector{Float64}
    hscale::Vector{Float64}
    emean::Vector{Float64}
    escale::Vector{Float64}
    A::Matrix{Float64}
    B::Matrix{Float64}
    C::Matrix{Float64}
    anchor_phi::Vector{Float64}
    anchor_theta::Vector{Float64}
end
function transition_stats(nn,z,u;theta=nn.theta)
    raw=vcat(z,u/9.5);input=normalized(raw,nn.fmean,nn.fscale)
    out,J=raw_with_jacobian(nn.re_theta(theta),input)
    normalization=Diagonal(Float64.(abs.((raw-nn.fmean)./nn.fscale).<6)./nn.fscale)
    J=J*normalization
    mean=nn.A*z+nn.B[:,1]*(u/9.5)+MEAN_F.*tanh.(out[1:NZ])
    jac=nn.A+Diagonal(MEAN_F.*(1 .-tanh.(out[1:NZ]).^2))*J[1:NZ,1:NZ]
    sd=STD_F_FLOOR+STD_F_SPAN.*sigmoid_safe(out[NZ+1:2NZ])
    mean,sd,jac
end
function observation_stats(nn,z)
    input=normalized(z,nn.hmean,nn.hscale)
    out,J=raw_with_jacobian(nn.re_psi(nn.psi),input)
    J=J*Diagonal(Float64.(abs.((z-nn.hmean)./nn.hscale).<6)./nn.hscale)
    mean=nn.C*z+MEAN_H.*tanh.(out[1:NY])
    jac=nn.C+Diagonal(MEAN_H.*(1 .-tanh.(out[1:NY]).^2))*J[1:NY,:]
    sd=STD_H_FLOOR+STD_H_SPAN.*sigmoid_safe(out[NY+1:2NY])
    mean,sd,jac
end
function feature_vector(m,P,residual,mask,u)
    diagp=max.(diag(P),1e-12)
    correlations=[P[i,j]/sqrt(diagp[i]*diagp[j]) for j in 1:NZ-1 for i in j+1:NZ]
    vcat(m,log.(diagp),correlations,residual.*mask,Float64.(mask),u/9.5)
end
function correction_context(nn,m,P,y,mask,u)
    pred,sd,H=observation_stats(nn,m)
    residual=y-pred;ids=findall(mask)
    fullS=Matrix(Symmetric(H*P*H'+Diagonal(sd.^2)))
    precision=zeros(NY,NY)
    if isempty(ids)
        refm=copy(m);refP=copy(P);surprise=0.;nll=0.
    else
        h=H[ids,:];R=Matrix(Diagonal(sd[ids].^2));S=fullS[ids,ids]
        K=(S\(h*P))';refm=m+K*residual[ids]
        D=Matrix{Float64}(I,NZ,NZ)-K*h
        refP=Matrix(Symmetric(D*P*D'+K*R*K'))
        e=residual[ids];surprise=.5dot(e,S\e)
        nll=surprise+.5*(logdet(S)+length(ids)*log(2pi))
        precision[ids,ids]=inv(S)
    end
    refP=covariance_proxy_projection(refP)
    features=feature_vector(m,P,residual,mask,u)
    (features=features,mean=refm,cov=refP,precision=precision,surprise=surprise,nll=nll,trust_radius=ENCODER_TRUST_RADIUS[])
end
function covariance_proxy_projection(P)
    E=eigen(Symmetric(P))
    Matrix(Symmetric(E.vectors*Diagonal(clamp.(E.values,COV_FLOOR,COV_CAP))*E.vectors'))
end
function encoded_belief(nn,context;phi=nn.phi)
    m,tau=neural_encoder(nn.re_phi(phi),reshape(context.features,:,1),reshape(context.mean,:,1),nn.emean,nn.escale)
    rawmean=vec(m);scales=exp.(vec(tau)/2)
    rho=sqrt(sum(abs2,rawmean[1:NX]-context.mean[1:NX])+sum((scales[1:NX].-1).^2 .* diag(context.cov)[1:NX]))
    radius=hasproperty(context,:trust_radius) ? context.trust_radius : Inf
    lambda=min(1.,radius/max(rho,1e-12))
    finalmean=context.mean+lambda*(rawmean-context.mean)
    D=Diagonal(1 .+lambda*(scales.-1));P=Matrix(Symmetric(D*context.cov*D))
    finalmean,P
end
function decode(m,P)
    S=Diagonal(ZS[1:NX]);S*m[1:NX],Matrix(Symmetric(S*P[1:NX,1:NX]*S))
end
function physical_coupling(m0,P0,m1,P1)
    # Common-normal coupling in fixed normalized physical coordinates.
    L0=cholesky(Symmetric(P0[1:NX,1:NX])).L
    L1=cholesky(Symmetric(P1[1:NX,1:NX])).L
    sqrt(sum(abs2,m1[1:NX]-m0[1:NX])+sum(abs2,L1-L0))
end
mutable struct NeuralObserver
    nn::NeuralSSM
    mean::Vector{Float64}
    cov::Matrix{Float64}
    previous_context
    previous_u::Float64
    replay::Vector{Any}
    tick::Int
    policy::Symbol
end
function NeuralObserver(nn,policy)
    variances=(vcat(.002,fill(deg2rad(.2),NP),.01,fill(.02,NP),deg2rad(.2),.3)./ZS).^2
    prior=vcat(.02,deg2rad(2.),fill(deg2rad(-1.),NP-1),zeros(NY),0.,0.)./ZS
    NeuralObserver(deepcopy(nn),prior,Matrix(Diagonal(variances)),nothing,0.,Any[],0,policy)
end
function predict_neural!(obs,u)
    m,sd,J=transition_stats(obs.nn,obs.mean,u)
    obs.mean=m;obs.cov=covariance_proxy_projection(J*obs.cov*J'+Diagonal(sd.^2))
    obs.previous_u=u
end
function make_bundle(phi,theta,psi,stats,A,B,C)
    _,rphi=flat_mlp(NFEAT,2NZ;seed=13)
    _,rtheta=flat_mlp(NZ+1,2NZ;seed=11)
    _,rpsi=flat_mlp(NZ,2NY;hidden=16,seed=12)
    NeuralSSM(copy(phi),copy(theta),copy(psi),rphi,rtheta,rpsi,
      stats.fmean,stats.fscale,stats.hmean,stats.hscale,stats.emean,stats.escale,
      A,B,C,copy(phi),copy(theta))
end
function read_bundle(folder=joinpath(@__DIR__,"models"))
    # Text weights and normalization arrays support loading across Julia versions.
    arrays=Dict(name=>Float64.(readdlm(joinpath(folder,name*".csv"),',')) for name in
      ["phi","theta","psi","fmean","fscale","hmean","hscale","emean","escale","A8","B8","C8"])
    stats=(fmean=vec(arrays["fmean"]),fscale=vec(arrays["fscale"]),hmean=vec(arrays["hmean"]),
      hscale=vec(arrays["hscale"]),emean=vec(arrays["emean"]),escale=vec(arrays["escale"]))
    make_bundle(vec(arrays["phi"]),vec(arrays["theta"]),vec(arrays["psi"]),stats,
      arrays["A8"],arrays["B8"],arrays["C8"])
end
